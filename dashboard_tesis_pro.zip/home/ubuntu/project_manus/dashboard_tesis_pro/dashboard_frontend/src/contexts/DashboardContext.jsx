import React, { createContext, useContext, useReducer, useEffect } from 'react'

// Estado inicial
const initialState = {
  config: {
    title: 'Dashboard Tesis Pro',
    version: '2.0.0',
    modules: {},
    theme: {
      primary_color: '#2196F3',
      secondary_color: '#1976D2',
      accent_color: '#FF9800'
    }
  },
  systemStatus: {
    overall_status: 'unknown',
    modules_status: {},
    last_update: null
  },
  modules: [],
  notifications: [],
  user: {
    name: 'Usuario',
    role: 'admin'
  },
  loading: {
    config: false,
    modules: false,
    system: false
  }
}

// Tipos de acciones
const actionTypes = {
  SET_CONFIG: 'SET_CONFIG',
  SET_SYSTEM_STATUS: 'SET_SYSTEM_STATUS',
  SET_MODULES: 'SET_MODULES',
  ADD_NOTIFICATION: 'ADD_NOTIFICATION',
  REMOVE_NOTIFICATION: 'REMOVE_NOTIFICATION',
  SET_LOADING: 'SET_LOADING',
  UPDATE_MODULE_STATUS: 'UPDATE_MODULE_STATUS'
}

// Reducer
function dashboardReducer(state, action) {
  switch (action.type) {
    case actionTypes.SET_CONFIG:
      return {
        ...state,
        config: { ...state.config, ...action.payload }
      }
    
    case actionTypes.SET_SYSTEM_STATUS:
      return {
        ...state,
        systemStatus: {
          ...action.payload,
          last_update: new Date().toISOString()
        }
      }
    
    case actionTypes.SET_MODULES:
      return {
        ...state,
        modules: action.payload
      }
    
    case actionTypes.ADD_NOTIFICATION:
      return {
        ...state,
        notifications: [...state.notifications, {
          id: Date.now(),
          timestamp: new Date().toISOString(),
          ...action.payload
        }]
      }
    
    case actionTypes.REMOVE_NOTIFICATION:
      return {
        ...state,
        notifications: state.notifications.filter(n => n.id !== action.payload)
      }
    
    case actionTypes.SET_LOADING:
      return {
        ...state,
        loading: { ...state.loading, ...action.payload }
      }
    
    case actionTypes.UPDATE_MODULE_STATUS:
      return {
        ...state,
        systemStatus: {
          ...state.systemStatus,
          modules_status: {
            ...state.systemStatus.modules_status,
            [action.payload.module]: action.payload.status
          }
        }
      }
    
    default:
      return state
  }
}

// Contexto
const DashboardContext = createContext()

// Hook personalizado para usar el contexto
export function useDashboard() {
  const context = useContext(DashboardContext)
  if (!context) {
    throw new Error('useDashboard debe usarse dentro de DashboardProvider')
  }
  return context
}

// Proveedor del contexto
export function DashboardProvider({ children }) {
  const [state, dispatch] = useReducer(dashboardReducer, initialState)

  // API base URL
  const API_BASE = 'http://localhost:3000/api'

  // Funciones de acción
  const actions = {
    // Cargar configuración
    async loadConfig() {
      dispatch({ type: actionTypes.SET_LOADING, payload: { config: true } })
      
      try {
        const response = await fetch(`${API_BASE}/config`)
        if (response.ok) {
          const config = await response.json()
          dispatch({ type: actionTypes.SET_CONFIG, payload: config })
        }
      } catch (error) {
        console.error('Error cargando configuración:', error)
        actions.addNotification({
          type: 'error',
          title: 'Error de Conexión',
          message: 'No se pudo cargar la configuración del sistema'
        })
      } finally {
        dispatch({ type: actionTypes.SET_LOADING, payload: { config: false } })
      }
    },

    // Cargar estado del sistema
    async loadSystemStatus() {
      try {
        const response = await fetch(`${API_BASE}/status`)
        if (response.ok) {
          const status = await response.json()
          dispatch({ type: actionTypes.SET_SYSTEM_STATUS, payload: status })
        }
      } catch (error) {
        console.error('Error cargando estado del sistema:', error)
      }
    },

    // Cargar módulos
    async loadModules() {
      dispatch({ type: actionTypes.SET_LOADING, payload: { modules: true } })
      
      try {
        const response = await fetch(`${API_BASE}/modules`)
        if (response.ok) {
          const data = await response.json()
          dispatch({ type: actionTypes.SET_MODULES, payload: data.modules || [] })
        }
      } catch (error) {
        console.error('Error cargando módulos:', error)
        actions.addNotification({
          type: 'error',
          title: 'Error de Módulos',
          message: 'No se pudo cargar la información de los módulos'
        })
      } finally {
        dispatch({ type: actionTypes.SET_LOADING, payload: { modules: false } })
      }
    },

    // Controlar módulo
    async controlModule(moduleId, action) {
      try {
        const response = await fetch(`${API_BASE}/modules/${moduleId}/${action}`, {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json'
          }
        })
        
        if (response.ok) {
          const result = await response.json()
          
          actions.addNotification({
            type: result.success ? 'success' : 'error',
            title: `Módulo ${moduleId}`,
            message: result.message || `Acción ${action} ejecutada`
          })
          
          // Recargar estado después de la acción
          setTimeout(() => {
            actions.loadSystemStatus()
            actions.loadModules()
          }, 2000)
          
          return result
        }
      } catch (error) {
        console.error(`Error controlando módulo ${moduleId}:`, error)
        actions.addNotification({
          type: 'error',
          title: 'Error de Control',
          message: `No se pudo ${action} el módulo ${moduleId}`
        })
      }
    },

    // Agregar notificación
    addNotification(notification) {
      dispatch({ type: actionTypes.ADD_NOTIFICATION, payload: notification })
      
      // Auto-remover después de 5 segundos
      setTimeout(() => {
        actions.removeNotification(notification.id || Date.now())
      }, 5000)
    },

    // Remover notificación
    removeNotification(id) {
      dispatch({ type: actionTypes.REMOVE_NOTIFICATION, payload: id })
    },

    // Actualizar estado de módulo
    updateModuleStatus(module, status) {
      dispatch({ 
        type: actionTypes.UPDATE_MODULE_STATUS, 
        payload: { module, status } 
      })
    },

    // Obtener métricas del sistema
    async getSystemMetrics() {
      try {
        const response = await fetch(`${API_BASE}/system/metrics`)
        if (response.ok) {
          return await response.json()
        }
      } catch (error) {
        console.error('Error obteniendo métricas:', error)
      }
      return null
    },

    // Obtener salud del sistema
    async getSystemHealth() {
      try {
        const response = await fetch(`${API_BASE}/system/health`)
        if (response.ok) {
          return await response.json()
        }
      } catch (error) {
        console.error('Error obteniendo salud del sistema:', error)
      }
      return null
    },

    // Proxy a módulo
    async proxyToModule(moduleId, endpoint, options = {}) {
      try {
        const url = `${API_BASE}/modules/${moduleId}/proxy/${endpoint}`
        const response = await fetch(url, {
          method: options.method || 'GET',
          headers: {
            'Content-Type': 'application/json',
            ...options.headers
          },
          body: options.body ? JSON.stringify(options.body) : undefined
        })
        
        if (response.ok) {
          return await response.json()
        }
      } catch (error) {
        console.error(`Error en proxy a ${moduleId}:`, error)
      }
      return null
    }
  }

  // Cargar datos iniciales
  useEffect(() => {
    actions.loadConfig()
    actions.loadSystemStatus()
    actions.loadModules()

    // Configurar actualizaciones periódicas
    const statusInterval = setInterval(() => {
      actions.loadSystemStatus()
    }, 30000) // Cada 30 segundos

    const modulesInterval = setInterval(() => {
      actions.loadModules()
    }, 60000) // Cada minuto

    return () => {
      clearInterval(statusInterval)
      clearInterval(modulesInterval)
    }
  }, [])

  // Valor del contexto
  const contextValue = {
    state,
    actions,
    
    // Getters convenientes
    get config() { return state.config },
    get systemStatus() { return state.systemStatus },
    get modules() { return state.modules },
    get notifications() { return state.notifications },
    get loading() { return state.loading },
    get user() { return state.user },
    
    // Estado derivado
    get isSystemHealthy() {
      return state.systemStatus.overall_status === 'healthy'
    },
    
    get onlineModulesCount() {
      return Object.values(state.systemStatus.modules_status || {})
        .filter(status => status === 'online').length
    },
    
    get totalModulesCount() {
      return Object.keys(state.config.modules || {}).length
    }
  }

  return (
    <DashboardContext.Provider value={contextValue}>
      {children}
    </DashboardContext.Provider>
  )
}

