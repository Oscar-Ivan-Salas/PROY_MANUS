import React, { useState, useEffect } from 'react'
import { motion } from 'framer-motion'
import { 
  Activity, 
  Database, 
  BarChart3, 
  FileText, 
  TrendingUp, 
  Users, 
  Clock,
  AlertTriangle,
  CheckCircle,
  ExternalLink,
  RefreshCw,
  Zap
} from 'lucide-react'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Badge } from '@/components/ui/badge'
import { Progress } from '@/components/ui/progress'
import { useDashboard } from '../contexts/DashboardContext'

const Dashboard = () => {
  const { 
    systemStatus, 
    modules, 
    actions, 
    onlineModulesCount, 
    totalModulesCount,
    isSystemHealthy 
  } = useDashboard()
  
  const [systemMetrics, setSystemMetrics] = useState(null)
  const [quickStats, setQuickStats] = useState({
    totalFiles: 0,
    totalAnalyses: 0,
    totalReports: 0,
    systemLoad: 0
  })

  // Cargar métricas del sistema
  useEffect(() => {
    const loadMetrics = async () => {
      const metrics = await actions.getSystemMetrics()
      if (metrics) {
        setSystemMetrics(metrics)
      }
    }

    loadMetrics()
    const interval = setInterval(loadMetrics, 30000) // Cada 30 segundos

    return () => clearInterval(interval)
  }, [])

  // Obtener estadísticas rápidas de módulos
  useEffect(() => {
    const loadQuickStats = async () => {
      try {
        // Estadísticas del explorador de archivos
        const fileStats = await actions.proxyToModule('file_explorer', 'api/stats')
        if (fileStats) {
          setQuickStats(prev => ({
            ...prev,
            totalFiles: fileStats.total_files || 0
          }))
        }
      } catch (error) {
        console.error('Error cargando estadísticas:', error)
      }
    }

    loadQuickStats()
  }, [])

  const getStatusColor = (status) => {
    switch (status) {
      case 'online':
        return 'text-green-600 bg-green-100'
      case 'offline':
        return 'text-red-600 bg-red-100'
      case 'warning':
        return 'text-yellow-600 bg-yellow-100'
      default:
        return 'text-gray-600 bg-gray-100'
    }
  }

  const getStatusIcon = (status) => {
    switch (status) {
      case 'online':
        return <CheckCircle className="w-4 h-4" />
      case 'offline':
        return <AlertTriangle className="w-4 h-4" />
      default:
        return <Clock className="w-4 h-4" />
    }
  }

  const moduleCards = [
    {
      id: 'file_explorer',
      title: 'Explorador de Archivos',
      description: 'Gestión profesional de archivos y datos',
      icon: Database,
      color: 'from-blue-500 to-blue-600',
      url: 'http://localhost:8058',
      stats: `${quickStats.totalFiles} archivos`
    },
    {
      id: 'data_analysis',
      title: 'Análisis Estadístico',
      description: 'Análisis avanzado y visualizaciones',
      icon: BarChart3,
      color: 'from-green-500 to-green-600',
      url: 'http://localhost:8050',
      stats: `${quickStats.totalAnalyses} análisis`
    },
    {
      id: 'report_generator',
      title: 'Generador de Informes',
      description: 'Reportes profesionales automáticos',
      icon: FileText,
      color: 'from-orange-500 to-orange-600',
      url: 'http://localhost:8070',
      stats: `${quickStats.totalReports} reportes`
    }
  ]

  const quickActions = [
    {
      title: 'Subir Archivo',
      description: 'Cargar nuevos datos',
      icon: Database,
      action: () => window.open('http://localhost:8058', '_blank'),
      enabled: systemStatus.modules_status?.file_explorer === 'online'
    },
    {
      title: 'Análisis Rápido',
      description: 'Ejecutar análisis básico',
      icon: Zap,
      action: () => window.open('http://localhost:8050', '_blank'),
      enabled: systemStatus.modules_status?.data_analysis === 'online'
    },
    {
      title: 'Generar Reporte',
      description: 'Crear reporte ejecutivo',
      icon: FileText,
      action: () => window.open('http://localhost:8070', '_blank'),
      enabled: systemStatus.modules_status?.report_generator === 'online'
    }
  ]

  return (
    <div className="space-y-6">
      {/* Header del Dashboard */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold text-gray-900">Dashboard Principal</h1>
          <p className="text-gray-600 mt-1">
            Vista general del sistema Dashboard Tesis Pro
          </p>
        </div>
        
        <div className="flex items-center space-x-3">
          <Badge 
            variant={isSystemHealthy ? "default" : "destructive"}
            className="px-3 py-1"
          >
            {isSystemHealthy ? 'Sistema Saludable' : 'Requiere Atención'}
          </Badge>
          
          <Button 
            onClick={() => {
              actions.loadSystemStatus()
              actions.loadModules()
            }}
            variant="outline"
            size="sm"
          >
            <RefreshCw className="w-4 h-4 mr-2" />
            Actualizar
          </Button>
        </div>
      </div>

      {/* Métricas principales */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.1 }}
        >
          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Módulos Activos</CardTitle>
              <Activity className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{onlineModulesCount}/{totalModulesCount}</div>
              <p className="text-xs text-muted-foreground">
                {Math.round((onlineModulesCount / totalModulesCount) * 100)}% operativo
              </p>
              <Progress 
                value={(onlineModulesCount / totalModulesCount) * 100} 
                className="mt-2"
              />
            </CardContent>
          </Card>
        </motion.div>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.2 }}
        >
          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Archivos Gestionados</CardTitle>
              <Database className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{quickStats.totalFiles}</div>
              <p className="text-xs text-muted-foreground">
                En el explorador de archivos
              </p>
            </CardContent>
          </Card>
        </motion.div>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.3 }}
        >
          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Análisis Realizados</CardTitle>
              <BarChart3 className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{quickStats.totalAnalyses}</div>
              <p className="text-xs text-muted-foreground">
                Análisis estadísticos completados
              </p>
            </CardContent>
          </Card>
        </motion.div>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.4 }}
        >
          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Reportes Generados</CardTitle>
              <FileText className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{quickStats.totalReports}</div>
              <p className="text-xs text-muted-foreground">
                Informes profesionales creados
              </p>
            </CardContent>
          </Card>
        </motion.div>
      </div>

      {/* Módulos del sistema */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {moduleCards.map((module, index) => {
          const status = systemStatus.modules_status?.[module.id] || 'offline'
          const isOnline = status === 'online'
          
          return (
            <motion.div
              key={module.id}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.5 + index * 0.1 }}
            >
              <Card className={`relative overflow-hidden ${isOnline ? 'hover:shadow-lg' : 'opacity-75'} transition-all duration-200`}>
                <div className={`absolute top-0 left-0 w-full h-1 bg-gradient-to-r ${module.color}`} />
                
                <CardHeader>
                  <div className="flex items-center justify-between">
                    <div className="flex items-center space-x-3">
                      <div className={`p-2 rounded-lg bg-gradient-to-r ${module.color}`}>
                        <module.icon className="w-5 h-5 text-white" />
                      </div>
                      <div>
                        <CardTitle className="text-lg">{module.title}</CardTitle>
                        <CardDescription>{module.description}</CardDescription>
                      </div>
                    </div>
                    
                    <Badge className={getStatusColor(status)}>
                      {getStatusIcon(status)}
                      <span className="ml-1 capitalize">{status}</span>
                    </Badge>
                  </div>
                </CardHeader>
                
                <CardContent>
                  <div className="flex items-center justify-between">
                    <span className="text-sm text-gray-600">{module.stats}</span>
                    
                    <div className="flex space-x-2">
                      {isOnline && (
                        <Button
                          size="sm"
                          onClick={() => window.open(module.url, '_blank')}
                          className="bg-gradient-to-r from-blue-500 to-blue-600 hover:from-blue-600 hover:to-blue-700"
                        >
                          <ExternalLink className="w-4 h-4 mr-1" />
                          Abrir
                        </Button>
                      )}
                      
                      <Button
                        size="sm"
                        variant="outline"
                        onClick={() => actions.controlModule(module.id, isOnline ? 'restart' : 'start')}
                      >
                        {isOnline ? 'Reiniciar' : 'Iniciar'}
                      </Button>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </motion.div>
          )
        })}
      </div>

      {/* Acciones rápidas */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center">
            <Zap className="w-5 h-5 mr-2" />
            Acciones Rápidas
          </CardTitle>
          <CardDescription>
            Accesos directos a las funciones más utilizadas
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            {quickActions.map((action, index) => (
              <motion.div
                key={action.title}
                initial={{ opacity: 0, x: -20 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ delay: 0.8 + index * 0.1 }}
              >
                <Button
                  variant="outline"
                  className={`w-full h-auto p-4 flex flex-col items-center space-y-2 ${
                    action.enabled ? 'hover:bg-gray-50' : 'opacity-50 cursor-not-allowed'
                  }`}
                  onClick={action.enabled ? action.action : undefined}
                  disabled={!action.enabled}
                >
                  <action.icon className="w-6 h-6" />
                  <div className="text-center">
                    <div className="font-medium">{action.title}</div>
                    <div className="text-xs text-gray-500">{action.description}</div>
                  </div>
                </Button>
              </motion.div>
            ))}
          </div>
        </CardContent>
      </Card>

      {/* Métricas del sistema (si están disponibles) */}
      {systemMetrics && (
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          <Card>
            <CardHeader>
              <CardTitle>Rendimiento del Sistema</CardTitle>
              <CardDescription>Métricas en tiempo real</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div>
                <div className="flex justify-between text-sm mb-1">
                  <span>CPU</span>
                  <span>{systemMetrics.cpu?.percent?.toFixed(1)}%</span>
                </div>
                <Progress value={systemMetrics.cpu?.percent || 0} />
              </div>
              
              <div>
                <div className="flex justify-between text-sm mb-1">
                  <span>Memoria</span>
                  <span>{systemMetrics.memory?.percent?.toFixed(1)}%</span>
                </div>
                <Progress value={systemMetrics.memory?.percent || 0} />
              </div>
              
              <div>
                <div className="flex justify-between text-sm mb-1">
                  <span>Disco</span>
                  <span>{((systemMetrics.disk?.usage?.used / systemMetrics.disk?.usage?.total) * 100)?.toFixed(1)}%</span>
                </div>
                <Progress value={(systemMetrics.disk?.usage?.used / systemMetrics.disk?.usage?.total) * 100 || 0} />
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>Estado de Conexiones</CardTitle>
              <CardDescription>Conectividad entre módulos</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-3">
                {Object.entries(systemStatus.modules_status || {}).map(([module, status]) => (
                  <div key={module} className="flex items-center justify-between">
                    <span className="text-sm font-medium capitalize">
                      {module.replace('_', ' ')}
                    </span>
                    <Badge className={getStatusColor(status)}>
                      {getStatusIcon(status)}
                      <span className="ml-1 capitalize">{status}</span>
                    </Badge>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </div>
      )}
    </div>
  )
}

export default Dashboard

