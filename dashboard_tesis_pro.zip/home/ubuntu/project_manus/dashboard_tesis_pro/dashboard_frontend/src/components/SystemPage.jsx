import React, { useState, useEffect } from 'react'
import { Routes, Route } from 'react-router-dom'
import { motion } from 'framer-motion'
import { 
  Activity, 
  Cpu, 
  HardDrive, 
  MemoryStick,
  Wifi,
  Settings,
  Download,
  RefreshCw,
  AlertTriangle,
  CheckCircle,
  Clock,
  Server,
  Database,
  Zap
} from 'lucide-react'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Badge } from '@/components/ui/badge'
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs'
import { Progress } from '@/components/ui/progress'
import { useDashboard } from '../contexts/DashboardContext'

const SystemPage = () => {
  const { systemStatus, actions } = useDashboard()
  const [systemMetrics, setSystemMetrics] = useState(null)
  const [systemHealth, setSystemHealth] = useState(null)
  const [systemInfo, setSystemInfo] = useState(null)
  const [loading, setLoading] = useState(false)

  // Cargar datos del sistema
  useEffect(() => {
    loadSystemData()
    
    // Actualizar cada 30 segundos
    const interval = setInterval(loadSystemData, 30000)
    return () => clearInterval(interval)
  }, [])

  const loadSystemData = async () => {
    try {
      const [metrics, health, info] = await Promise.all([
        actions.getSystemMetrics(),
        actions.getSystemHealth(),
        fetch('http://localhost:3000/api/system/info').then(r => r.ok ? r.json() : null)
      ])

      setSystemMetrics(metrics)
      setSystemHealth(health)
      setSystemInfo(info)
    } catch (error) {
      console.error('Error cargando datos del sistema:', error)
    }
  }

  const handleRefresh = async () => {
    setLoading(true)
    await loadSystemData()
    await actions.loadSystemStatus()
    setLoading(false)
    
    actions.addNotification({
      type: 'success',
      title: 'Sistema Actualizado',
      message: 'Datos del sistema actualizados correctamente'
    })
  }

  const getHealthColor = (status) => {
    switch (status) {
      case 'healthy':
        return 'text-green-600 bg-green-100'
      case 'warning':
        return 'text-yellow-600 bg-yellow-100'
      case 'critical':
        return 'text-red-600 bg-red-100'
      default:
        return 'text-gray-600 bg-gray-100'
    }
  }

  const getHealthIcon = (status) => {
    switch (status) {
      case 'healthy':
        return <CheckCircle className="w-4 h-4" />
      case 'warning':
        return <AlertTriangle className="w-4 h-4" />
      case 'critical':
        return <AlertTriangle className="w-4 h-4" />
      default:
        return <Clock className="w-4 h-4" />
    }
  }

  const formatBytes = (bytes) => {
    if (!bytes) return '0 B'
    const k = 1024
    const sizes = ['B', 'KB', 'MB', 'GB', 'TB']
    const i = Math.floor(Math.log(bytes) / Math.log(k))
    return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i]
  }

  const SystemOverview = () => (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold text-gray-900">Estado del Sistema</h1>
          <p className="text-gray-600 mt-1">
            Monitoreo y métricas del Dashboard Tesis Pro
          </p>
        </div>
        
        <Button 
          onClick={handleRefresh}
          disabled={loading}
          variant="outline"
        >
          <RefreshCw className={`w-4 h-4 mr-2 ${loading ? 'animate-spin' : ''}`} />
          Actualizar
        </Button>
      </div>

      {/* Estado general */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center">
            <Activity className="w-5 h-5 mr-2" />
            Estado General del Sistema
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
            <div className="text-center p-4 bg-gray-50 rounded-lg">
              <div className={`w-12 h-12 mx-auto mb-2 rounded-full flex items-center justify-center ${
                systemHealth?.overall_status === 'healthy' ? 'bg-green-100' : 
                systemHealth?.overall_status === 'warning' ? 'bg-yellow-100' : 'bg-red-100'
              }`}>
                {getHealthIcon(systemHealth?.overall_status)}
              </div>
              <div className="font-medium">
                {systemHealth?.overall_status === 'healthy' ? 'Saludable' :
                 systemHealth?.overall_status === 'warning' ? 'Advertencia' : 'Crítico'}
              </div>
              <div className="text-sm text-gray-500">Estado general</div>
            </div>

            <div className="text-center p-4 bg-gray-50 rounded-lg">
              <div className="w-12 h-12 mx-auto mb-2 rounded-full bg-blue-100 flex items-center justify-center">
                <Server className="w-6 h-6 text-blue-600" />
              </div>
              <div className="font-medium">
                {Object.values(systemStatus.modules_status || {}).filter(s => s === 'online').length}/3
              </div>
              <div className="text-sm text-gray-500">Módulos activos</div>
            </div>

            <div className="text-center p-4 bg-gray-50 rounded-lg">
              <div className="w-12 h-12 mx-auto mb-2 rounded-full bg-purple-100 flex items-center justify-center">
                <Cpu className="w-6 h-6 text-purple-600" />
              </div>
              <div className="font-medium">
                {systemMetrics?.cpu?.percent?.toFixed(1) || '0'}%
              </div>
              <div className="text-sm text-gray-500">Uso de CPU</div>
            </div>

            <div className="text-center p-4 bg-gray-50 rounded-lg">
              <div className="w-12 h-12 mx-auto mb-2 rounded-full bg-orange-100 flex items-center justify-center">
                <MemoryStick className="w-6 h-6 text-orange-600" />
              </div>
              <div className="font-medium">
                {systemMetrics?.memory?.percent?.toFixed(1) || '0'}%
              </div>
              <div className="text-sm text-gray-500">Uso de memoria</div>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Métricas de rendimiento */}
      {systemMetrics && (
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          <Card>
            <CardHeader>
              <CardTitle>Rendimiento del Sistema</CardTitle>
              <CardDescription>Métricas en tiempo real</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div>
                <div className="flex justify-between text-sm mb-1">
                  <span className="flex items-center">
                    <Cpu className="w-4 h-4 mr-1" />
                    CPU
                  </span>
                  <span>{systemMetrics.cpu?.percent?.toFixed(1)}%</span>
                </div>
                <Progress value={systemMetrics.cpu?.percent || 0} />
              </div>
              
              <div>
                <div className="flex justify-between text-sm mb-1">
                  <span className="flex items-center">
                    <MemoryStick className="w-4 h-4 mr-1" />
                    Memoria
                  </span>
                  <span>{systemMetrics.memory?.percent?.toFixed(1)}%</span>
                </div>
                <Progress value={systemMetrics.memory?.percent || 0} />
                <div className="text-xs text-gray-500 mt-1">
                  {formatBytes(systemMetrics.memory?.used)} / {formatBytes(systemMetrics.memory?.total)}
                </div>
              </div>
              
              <div>
                <div className="flex justify-between text-sm mb-1">
                  <span className="flex items-center">
                    <HardDrive className="w-4 h-4 mr-1" />
                    Disco
                  </span>
                  <span>
                    {((systemMetrics.disk?.usage?.used / systemMetrics.disk?.usage?.total) * 100)?.toFixed(1)}%
                  </span>
                </div>
                <Progress value={(systemMetrics.disk?.usage?.used / systemMetrics.disk?.usage?.total) * 100 || 0} />
                <div className="text-xs text-gray-500 mt-1">
                  {formatBytes(systemMetrics.disk?.usage?.used)} / {formatBytes(systemMetrics.disk?.usage?.total)}
                </div>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>Estado de Módulos</CardTitle>
              <CardDescription>Conectividad y rendimiento</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-3">
                {Object.entries(systemStatus.modules_status || {}).map(([module, status]) => (
                  <div key={module} className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
                    <div className="flex items-center space-x-3">
                      <div className={`w-3 h-3 rounded-full ${
                        status === 'online' ? 'bg-green-500' : 'bg-red-500'
                      }`} />
                      <span className="font-medium capitalize">
                        {module.replace('_', ' ')}
                      </span>
                    </div>
                    <Badge className={getHealthColor(status === 'online' ? 'healthy' : 'critical')}>
                      {status}
                    </Badge>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </div>
      )}

      {/* Información del sistema */}
      {systemInfo && (
        <Card>
          <CardHeader>
            <CardTitle>Información del Sistema</CardTitle>
            <CardDescription>Detalles del entorno de ejecución</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
              <div className="space-y-2">
                <h4 className="font-medium text-sm text-gray-700">Sistema Operativo</h4>
                <div className="text-sm text-gray-600">
                  <div>{systemInfo.os?.name} {systemInfo.os?.version}</div>
                  <div>{systemInfo.os?.architecture}</div>
                  <div>Host: {systemInfo.os?.hostname}</div>
                </div>
              </div>

              <div className="space-y-2">
                <h4 className="font-medium text-sm text-gray-700">Python</h4>
                <div className="text-sm text-gray-600">
                  <div>Versión: {systemInfo.python?.version}</div>
                  <div>Implementación: {systemInfo.python?.implementation}</div>
                </div>
              </div>

              <div className="space-y-2">
                <h4 className="font-medium text-sm text-gray-700">Hardware</h4>
                <div className="text-sm text-gray-600">
                  <div>CPUs: {systemInfo.hardware?.cpu_count}</div>
                  <div>Memoria: {formatBytes(systemInfo.hardware?.memory_total)}</div>
                  <div>Disco: {formatBytes(systemInfo.hardware?.disk_total)}</div>
                </div>
              </div>

              <div className="space-y-2">
                <h4 className="font-medium text-sm text-gray-700">Dashboard</h4>
                <div className="text-sm text-gray-600">
                  <div>Versión: {systemInfo.dashboard?.version}</div>
                  <div>Entorno: {systemInfo.dashboard?.environment}</div>
                  <div>PID: {systemInfo.dashboard?.pid}</div>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>
      )}

      {/* Verificaciones de salud */}
      {systemHealth && (
        <Card>
          <CardHeader>
            <CardTitle>Verificaciones de Salud</CardTitle>
            <CardDescription>Estado detallado de componentes del sistema</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-3">
              {Object.entries(systemHealth.checks || {}).map(([check, data]) => (
                <div key={check} className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
                  <div className="flex items-center space-x-3">
                    <div className={`w-3 h-3 rounded-full ${
                      data.status === 'healthy' ? 'bg-green-500' :
                      data.status === 'warning' ? 'bg-yellow-500' : 'bg-red-500'
                    }`} />
                    <div>
                      <span className="font-medium capitalize">{check}</span>
                      {data.value && (
                        <span className="text-sm text-gray-500 ml-2">
                          {data.value}{data.unit && ` ${data.unit}`}
                        </span>
                      )}
                    </div>
                  </div>
                  <Badge className={getHealthColor(data.status)}>
                    {data.status}
                  </Badge>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  )

  const SystemSettings = () => (
    <div className="space-y-6">
      <div>
        <h1 className="text-3xl font-bold text-gray-900">Configuración del Sistema</h1>
        <p className="text-gray-600 mt-1">
          Ajustes y configuración del Dashboard Tesis Pro
        </p>
      </div>

      <Card>
        <CardHeader>
          <CardTitle>Configuración General</CardTitle>
          <CardDescription>
            Ajustes básicos del sistema
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            <div className="flex items-center justify-between p-4 bg-gray-50 rounded-lg">
              <div>
                <h4 className="font-medium">Inicio Automático de Módulos</h4>
                <p className="text-sm text-gray-600">Iniciar módulos automáticamente al arrancar</p>
              </div>
              <Button variant="outline" size="sm">
                Configurar
              </Button>
            </div>

            <div className="flex items-center justify-between p-4 bg-gray-50 rounded-lg">
              <div>
                <h4 className="font-medium">Intervalo de Monitoreo</h4>
                <p className="text-sm text-gray-600">Frecuencia de actualización de métricas</p>
              </div>
              <Button variant="outline" size="sm">
                Ajustar
              </Button>
            </div>

            <div className="flex items-center justify-between p-4 bg-gray-50 rounded-lg">
              <div>
                <h4 className="font-medium">Nivel de Logging</h4>
                <p className="text-sm text-gray-600">Detalle de los logs del sistema</p>
              </div>
              <Button variant="outline" size="sm">
                Cambiar
              </Button>
            </div>
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle>Acciones del Sistema</CardTitle>
          <CardDescription>
            Operaciones de mantenimiento y gestión
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <Button variant="outline" className="h-auto p-4 flex flex-col items-center space-y-2">
              <Download className="w-6 h-6" />
              <div className="text-center">
                <div className="font-medium">Crear Backup</div>
                <div className="text-xs text-gray-500">Respaldar configuración</div>
              </div>
            </Button>

            <Button variant="outline" className="h-auto p-4 flex flex-col items-center space-y-2">
              <RefreshCw className="w-6 h-6" />
              <div className="text-center">
                <div className="font-medium">Reiniciar Sistema</div>
                <div className="text-xs text-gray-500">Reinicio controlado</div>
              </div>
            </Button>

            <Button variant="outline" className="h-auto p-4 flex flex-col items-center space-y-2">
              <Database className="w-6 h-6" />
              <div className="text-center">
                <div className="font-medium">Limpiar Cache</div>
                <div className="text-xs text-gray-500">Liberar memoria</div>
              </div>
            </Button>

            <Button variant="outline" className="h-auto p-4 flex flex-col items-center space-y-2">
              <Zap className="w-6 h-6" />
              <div className="text-center">
                <div className="font-medium">Optimizar Sistema</div>
                <div className="text-xs text-gray-500">Mejorar rendimiento</div>
              </div>
            </Button>
          </div>
        </CardContent>
      </Card>
    </div>
  )

  return (
    <Routes>
      <Route path="/" element={<SystemOverview />} />
      <Route path="/status" element={<SystemOverview />} />
      <Route path="/settings" element={<SystemSettings />} />
    </Routes>
  )
}

export default SystemPage

