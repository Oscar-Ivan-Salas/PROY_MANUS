import React, { useState, useEffect } from 'react'
import { Routes, Route, Link, useLocation } from 'react-router-dom'
import { motion } from 'framer-motion'
import { 
  Database, 
  BarChart3, 
  FileText, 
  Play, 
  Square, 
  RotateCcw,
  ExternalLink,
  Settings,
  Activity,
  AlertCircle,
  CheckCircle,
  Clock,
  Cpu,
  HardDrive,
  Wifi
} from 'lucide-react'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Badge } from '@/components/ui/badge'
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs'
import { Progress } from '@/components/ui/progress'
import { useDashboard } from '../contexts/DashboardContext'

const ModulesPage = () => {
  const location = useLocation()
  const { modules, systemStatus, actions } = useDashboard()
  const [selectedModule, setSelectedModule] = useState(null)
  const [moduleStats, setModuleStats] = useState({})

  const moduleConfigs = {
    file_explorer: {
      name: 'Explorador de Archivos Profesional',
      description: 'Gestión avanzada de archivos con FileBrowser y API REST',
      icon: Database,
      color: 'from-blue-500 to-blue-600',
      url: 'http://localhost:8058',
      apiUrl: 'http://localhost:8060',
      features: [
        'Navegación de archivos profesional',
        'Subida y descarga de archivos',
        'Gestión de permisos por roles',
        'API REST para integración',
        'Estructura organizada para tesis'
      ]
    },
    data_analysis: {
      name: 'Análisis Estadístico Interactivo',
      description: 'Análisis avanzado con Streamlit, pandas y plotly',
      icon: BarChart3,
      color: 'from-green-500 to-green-600',
      url: 'http://localhost:8050',
      features: [
        'Análisis estadísticos inferenciales',
        'Visualizaciones interactivas',
        'Clustering automático',
        'Validación de datos',
        'Exportación de resultados'
      ]
    },
    report_generator: {
      name: 'Generador de Informes Profesionales',
      description: 'Reportes automáticos en múltiples formatos',
      icon: FileText,
      color: 'from-orange-500 to-orange-600',
      url: 'http://localhost:8070',
      features: [
        'Reportes ejecutivos automáticos',
        'Múltiples formatos (HTML, PDF, Word)',
        'Plantillas personalizables',
        'Integración de gráficos',
        'Historial de reportes'
      ]
    }
  }

  useEffect(() => {
    // Cargar estadísticas de módulos
    const loadModuleStats = async () => {
      const stats = {}
      
      for (const moduleId of Object.keys(moduleConfigs)) {
        try {
          const moduleData = await actions.proxyToModule(moduleId, 'api/stats')
          if (moduleData) {
            stats[moduleId] = moduleData
          }
        } catch (error) {
          console.error(`Error cargando stats de ${moduleId}:`, error)
        }
      }
      
      setModuleStats(stats)
    }

    loadModuleStats()
    const interval = setInterval(loadModuleStats, 60000) // Cada minuto

    return () => clearInterval(interval)
  }, [])

  const getStatusColor = (status) => {
    switch (status) {
      case 'online':
        return 'text-green-600 bg-green-100'
      case 'offline':
        return 'text-red-600 bg-red-100'
      case 'warning':
        return 'text-yellow-600 bg-yellow-100'
      default:
        return 'text-gray-600 bg-gray-100'
    }
  }

  const getStatusIcon = (status) => {
    switch (status) {
      case 'online':
        return <CheckCircle className="w-4 h-4" />
      case 'offline':
        return <AlertCircle className="w-4 h-4" />
      default:
        return <Clock className="w-4 h-4" />
    }
  }

  const handleModuleAction = async (moduleId, action) => {
    await actions.controlModule(moduleId, action)
  }

  const ModuleCard = ({ moduleId, config }) => {
    const status = systemStatus.modules_status?.[moduleId] || 'offline'
    const isOnline = status === 'online'
    const stats = moduleStats[moduleId] || {}

    return (
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        whileHover={{ y: -5 }}
        transition={{ duration: 0.2 }}
      >
        <Card className={`relative overflow-hidden ${isOnline ? 'border-green-200' : 'border-red-200'} hover:shadow-lg transition-all duration-200`}>
          <div className={`absolute top-0 left-0 w-full h-1 bg-gradient-to-r ${config.color}`} />
          
          <CardHeader>
            <div className="flex items-start justify-between">
              <div className="flex items-center space-x-3">
                <div className={`p-3 rounded-xl bg-gradient-to-r ${config.color}`}>
                  <config.icon className="w-6 h-6 text-white" />
                </div>
                <div>
                  <CardTitle className="text-lg">{config.name}</CardTitle>
                  <CardDescription className="mt-1">{config.description}</CardDescription>
                </div>
              </div>
              
              <Badge className={getStatusColor(status)}>
                {getStatusIcon(status)}
                <span className="ml-1 capitalize">{status}</span>
              </Badge>
            </div>
          </CardHeader>
          
          <CardContent className="space-y-4">
            {/* Características principales */}
            <div>
              <h4 className="font-medium text-sm text-gray-700 mb-2">Características:</h4>
              <ul className="text-xs text-gray-600 space-y-1">
                {config.features.slice(0, 3).map((feature, index) => (
                  <li key={index} className="flex items-center">
                    <div className="w-1 h-1 bg-gray-400 rounded-full mr-2" />
                    {feature}
                  </li>
                ))}
              </ul>
            </div>

            {/* Estadísticas si están disponibles */}
            {isOnline && stats && Object.keys(stats).length > 0 && (
              <div className="bg-gray-50 rounded-lg p-3">
                <h4 className="font-medium text-sm text-gray-700 mb-2">Estadísticas:</h4>
                <div className="grid grid-cols-2 gap-2 text-xs">
                  {stats.total_files && (
                    <div>
                      <span className="text-gray-500">Archivos:</span>
                      <span className="font-medium ml-1">{stats.total_files}</span>
                    </div>
                  )}
                  {stats.uptime && (
                    <div>
                      <span className="text-gray-500">Uptime:</span>
                      <span className="font-medium ml-1">{stats.uptime}</span>
                    </div>
                  )}
                </div>
              </div>
            )}

            {/* Controles */}
            <div className="flex items-center justify-between pt-2 border-t">
              <div className="flex space-x-2">
                {!isOnline ? (
                  <Button
                    size="sm"
                    onClick={() => handleModuleAction(moduleId, 'start')}
                    className="bg-green-600 hover:bg-green-700"
                  >
                    <Play className="w-4 h-4 mr-1" />
                    Iniciar
                  </Button>
                ) : (
                  <>
                    <Button
                      size="sm"
                      variant="outline"
                      onClick={() => handleModuleAction(moduleId, 'restart')}
                    >
                      <RotateCcw className="w-4 h-4 mr-1" />
                      Reiniciar
                    </Button>
                    <Button
                      size="sm"
                      variant="destructive"
                      onClick={() => handleModuleAction(moduleId, 'stop')}
                    >
                      <Square className="w-4 h-4 mr-1" />
                      Detener
                    </Button>
                  </>
                )}
              </div>

              {isOnline && (
                <Button
                  size="sm"
                  onClick={() => window.open(config.url, '_blank')}
                  className={`bg-gradient-to-r ${config.color} hover:opacity-90`}
                >
                  <ExternalLink className="w-4 h-4 mr-1" />
                  Abrir
                </Button>
              )}
            </div>
          </CardContent>
        </Card>
      </motion.div>
    )
  }

  const ModuleDetails = ({ moduleId }) => {
    const config = moduleConfigs[moduleId]
    const status = systemStatus.modules_status?.[moduleId] || 'offline'
    const isOnline = status === 'online'
    const stats = moduleStats[moduleId] || {}

    if (!config) {
      return <div>Módulo no encontrado</div>
    }

    return (
      <div className="space-y-6">
        {/* Header del módulo */}
        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-4">
            <div className={`p-4 rounded-xl bg-gradient-to-r ${config.color}`}>
              <config.icon className="w-8 h-8 text-white" />
            </div>
            <div>
              <h1 className="text-2xl font-bold text-gray-900">{config.name}</h1>
              <p className="text-gray-600">{config.description}</p>
            </div>
          </div>
          
          <Badge className={getStatusColor(status)} variant="outline">
            {getStatusIcon(status)}
            <span className="ml-2 capitalize">{status}</span>
          </Badge>
        </div>

        <Tabs defaultValue="overview" className="w-full">
          <TabsList>
            <TabsTrigger value="overview">Vista General</TabsTrigger>
            <TabsTrigger value="features">Características</TabsTrigger>
            <TabsTrigger value="stats">Estadísticas</TabsTrigger>
            <TabsTrigger value="controls">Controles</TabsTrigger>
          </TabsList>

          <TabsContent value="overview" className="space-y-4">
            <Card>
              <CardHeader>
                <CardTitle>Estado del Módulo</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                  <div className="text-center p-4 bg-gray-50 rounded-lg">
                    <div className={`w-12 h-12 mx-auto mb-2 rounded-full flex items-center justify-center ${
                      isOnline ? 'bg-green-100' : 'bg-red-100'
                    }`}>
                      {isOnline ? (
                        <CheckCircle className="w-6 h-6 text-green-600" />
                      ) : (
                        <AlertCircle className="w-6 h-6 text-red-600" />
                      )}
                    </div>
                    <div className="font-medium">{isOnline ? 'En Línea' : 'Fuera de Línea'}</div>
                    <div className="text-sm text-gray-500">Estado del servicio</div>
                  </div>

                  <div className="text-center p-4 bg-gray-50 rounded-lg">
                    <div className="w-12 h-12 mx-auto mb-2 rounded-full bg-blue-100 flex items-center justify-center">
                      <Wifi className="w-6 h-6 text-blue-600" />
                    </div>
                    <div className="font-medium">{config.url.split('//')[1]}</div>
                    <div className="text-sm text-gray-500">Dirección de acceso</div>
                  </div>

                  <div className="text-center p-4 bg-gray-50 rounded-lg">
                    <div className="w-12 h-12 mx-auto mb-2 rounded-full bg-purple-100 flex items-center justify-center">
                      <Activity className="w-6 h-6 text-purple-600" />
                    </div>
                    <div className="font-medium">{stats.uptime || 'N/A'}</div>
                    <div className="text-sm text-gray-500">Tiempo activo</div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="features" className="space-y-4">
            <Card>
              <CardHeader>
                <CardTitle>Características del Módulo</CardTitle>
                <CardDescription>
                  Funcionalidades principales disponibles en este módulo
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  {config.features.map((feature, index) => (
                    <div key={index} className="flex items-center space-x-3 p-3 bg-gray-50 rounded-lg">
                      <div className="w-2 h-2 bg-blue-500 rounded-full" />
                      <span className="text-sm">{feature}</span>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="stats" className="space-y-4">
            <Card>
              <CardHeader>
                <CardTitle>Estadísticas y Métricas</CardTitle>
                <CardDescription>
                  Información detallada sobre el rendimiento del módulo
                </CardDescription>
              </CardHeader>
              <CardContent>
                {isOnline ? (
                  <div className="space-y-4">
                    {Object.entries(stats).map(([key, value]) => (
                      <div key={key} className="flex justify-between items-center py-2 border-b">
                        <span className="text-sm font-medium capitalize">
                          {key.replace('_', ' ')}
                        </span>
                        <span className="text-sm text-gray-600">{value}</span>
                      </div>
                    ))}
                    
                    {Object.keys(stats).length === 0 && (
                      <div className="text-center py-8 text-gray-500">
                        No hay estadísticas disponibles
                      </div>
                    )}
                  </div>
                ) : (
                  <div className="text-center py-8 text-gray-500">
                    El módulo debe estar en línea para mostrar estadísticas
                  </div>
                )}
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="controls" className="space-y-4">
            <Card>
              <CardHeader>
                <CardTitle>Controles del Módulo</CardTitle>
                <CardDescription>
                  Gestión y control del estado del módulo
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div className="flex items-center justify-between p-4 bg-gray-50 rounded-lg">
                    <div>
                      <h4 className="font-medium">Estado del Servicio</h4>
                      <p className="text-sm text-gray-600">Controlar el estado de ejecución</p>
                    </div>
                    <div className="flex space-x-2">
                      {!isOnline ? (
                        <Button
                          onClick={() => handleModuleAction(moduleId, 'start')}
                          className="bg-green-600 hover:bg-green-700"
                        >
                          <Play className="w-4 h-4 mr-2" />
                          Iniciar
                        </Button>
                      ) : (
                        <>
                          <Button
                            variant="outline"
                            onClick={() => handleModuleAction(moduleId, 'restart')}
                          >
                            <RotateCcw className="w-4 h-4 mr-2" />
                            Reiniciar
                          </Button>
                          <Button
                            variant="destructive"
                            onClick={() => handleModuleAction(moduleId, 'stop')}
                          >
                            <Square className="w-4 h-4 mr-2" />
                            Detener
                          </Button>
                        </>
                      )}
                    </div>
                  </div>

                  {isOnline && (
                    <div className="flex items-center justify-between p-4 bg-gray-50 rounded-lg">
                      <div>
                        <h4 className="font-medium">Acceso Directo</h4>
                        <p className="text-sm text-gray-600">Abrir interfaz del módulo</p>
                      </div>
                      <Button
                        onClick={() => window.open(config.url, '_blank')}
                        className={`bg-gradient-to-r ${config.color} hover:opacity-90`}
                      >
                        <ExternalLink className="w-4 h-4 mr-2" />
                        Abrir Módulo
                      </Button>
                    </div>
                  )}
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    )
  }

  return (
    <div className="space-y-6">
      <Routes>
        <Route path="/" element={
          <>
            {/* Header */}
            <div className="flex items-center justify-between">
              <div>
                <h1 className="text-3xl font-bold text-gray-900">Gestión de Módulos</h1>
                <p className="text-gray-600 mt-1">
                  Control y monitoreo de los módulos del sistema
                </p>
              </div>
              
              <Button 
                onClick={() => {
                  actions.loadSystemStatus()
                  actions.loadModules()
                }}
                variant="outline"
              >
                <Activity className="w-4 h-4 mr-2" />
                Actualizar Estado
              </Button>
            </div>

            {/* Resumen de estado */}
            <Card>
              <CardHeader>
                <CardTitle>Estado General de Módulos</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                  {Object.entries(moduleConfigs).map(([moduleId, config]) => {
                    const status = systemStatus.modules_status?.[moduleId] || 'offline'
                    const isOnline = status === 'online'
                    
                    return (
                      <div key={moduleId} className="flex items-center space-x-3 p-3 bg-gray-50 rounded-lg">
                        <config.icon className="w-5 h-5 text-gray-600" />
                        <div className="flex-1">
                          <div className="font-medium text-sm">{config.name}</div>
                          <Badge className={`${getStatusColor(status)} text-xs`}>
                            {status}
                          </Badge>
                        </div>
                      </div>
                    )
                  })}
                </div>
              </CardContent>
            </Card>

            {/* Grid de módulos */}
            <div className="grid grid-cols-1 lg:grid-cols-2 xl:grid-cols-3 gap-6">
              {Object.entries(moduleConfigs).map(([moduleId, config]) => (
                <ModuleCard key={moduleId} moduleId={moduleId} config={config} />
              ))}
            </div>
          </>
        } />
        
        <Route path="/:moduleId" element={
          <ModuleDetails moduleId={location.pathname.split('/').pop()} />
        } />
      </Routes>
    </div>
  )
}

export default ModulesPage

