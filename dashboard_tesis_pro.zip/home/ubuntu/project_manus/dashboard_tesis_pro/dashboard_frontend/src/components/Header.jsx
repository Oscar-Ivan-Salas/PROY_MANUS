import React, { useState } from 'react'
import { motion, AnimatePresence } from 'framer-motion'
import { 
  Menu, 
  Bell, 
  Search, 
  Settings, 
  User, 
  LogOut,
  Refresh,
  Wifi,
  WifiOff,
  AlertCircle,
  CheckCircle,
  Clock
} from 'lucide-react'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { 
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu'
import { Badge } from '@/components/ui/badge'
import { useDashboard } from '../contexts/DashboardContext'

const Header = ({ onToggleSidebar, sidebarOpen }) => {
  const { systemStatus, notifications, actions, onlineModulesCount, totalModulesCount } = useDashboard()
  const [searchQuery, setSearchQuery] = useState('')
  const [showNotifications, setShowNotifications] = useState(false)

  const getSystemStatusIcon = () => {
    switch (systemStatus.overall_status) {
      case 'healthy':
        return <CheckCircle className="w-4 h-4 text-green-500" />
      case 'degraded':
        return <AlertCircle className="w-4 h-4 text-yellow-500" />
      case 'critical':
        return <WifiOff className="w-4 h-4 text-red-500" />
      default:
        return <Wifi className="w-4 h-4 text-gray-400" />
    }
  }

  const getSystemStatusText = () => {
    switch (systemStatus.overall_status) {
      case 'healthy':
        return 'Sistema Saludable'
      case 'degraded':
        return 'Sistema Degradado'
      case 'critical':
        return 'Sistema Crítico'
      default:
        return 'Estado Desconocido'
    }
  }

  const handleRefresh = async () => {
    await actions.loadSystemStatus()
    await actions.loadModules()
    actions.addNotification({
      type: 'success',
      title: 'Actualización',
      message: 'Estado del sistema actualizado'
    })
  }

  const formatTime = (timestamp) => {
    if (!timestamp) return 'Nunca'
    return new Date(timestamp).toLocaleTimeString('es-ES', {
      hour: '2-digit',
      minute: '2-digit'
    })
  }

  return (
    <header className="bg-white border-b border-gray-200 px-6 py-4 flex items-center justify-between">
      {/* Lado izquierdo */}
      <div className="flex items-center space-x-4">
        {/* Botón de menú */}
        <Button
          variant="ghost"
          size="sm"
          onClick={onToggleSidebar}
          className="p-2"
        >
          <Menu className="w-5 h-5" />
        </Button>

        {/* Breadcrumb/Título */}
        <div>
          <h1 className="text-xl font-semibold text-gray-900">
            Dashboard Principal
          </h1>
          <p className="text-sm text-gray-500">
            Panel de control unificado
          </p>
        </div>
      </div>

      {/* Centro - Barra de búsqueda */}
      <div className="flex-1 max-w-md mx-8">
        <div className="relative">
          <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 w-4 h-4 text-gray-400" />
          <Input
            type="text"
            placeholder="Buscar módulos, archivos, reportes..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="pl-10 pr-4"
          />
        </div>
      </div>

      {/* Lado derecho */}
      <div className="flex items-center space-x-4">
        {/* Estado del sistema */}
        <div className="flex items-center space-x-2 px-3 py-1.5 bg-gray-50 rounded-lg">
          {getSystemStatusIcon()}
          <span className="text-sm font-medium text-gray-700">
            {onlineModulesCount}/{totalModulesCount}
          </span>
          <span className="text-xs text-gray-500 hidden sm:inline">
            módulos activos
          </span>
        </div>

        {/* Botón de actualizar */}
        <Button
          variant="ghost"
          size="sm"
          onClick={handleRefresh}
          className="p-2"
          title="Actualizar estado"
        >
          <Refresh className="w-4 h-4" />
        </Button>

        {/* Notificaciones */}
        <DropdownMenu open={showNotifications} onOpenChange={setShowNotifications}>
          <DropdownMenuTrigger asChild>
            <Button variant="ghost" size="sm" className="p-2 relative">
              <Bell className="w-4 h-4" />
              {notifications.length > 0 && (
                <Badge 
                  variant="destructive" 
                  className="absolute -top-1 -right-1 w-5 h-5 text-xs flex items-center justify-center p-0"
                >
                  {notifications.length}
                </Badge>
              )}
            </Button>
          </DropdownMenuTrigger>
          <DropdownMenuContent align="end" className="w-80">
            <DropdownMenuLabel className="flex items-center justify-between">
              Notificaciones
              {notifications.length > 0 && (
                <Badge variant="secondary">{notifications.length}</Badge>
              )}
            </DropdownMenuLabel>
            <DropdownMenuSeparator />
            
            {notifications.length === 0 ? (
              <div className="p-4 text-center text-gray-500 text-sm">
                No hay notificaciones
              </div>
            ) : (
              <div className="max-h-64 overflow-y-auto">
                {notifications.slice(0, 5).map((notification) => (
                  <DropdownMenuItem 
                    key={notification.id}
                    className="flex items-start space-x-3 p-3 cursor-pointer"
                    onClick={() => actions.removeNotification(notification.id)}
                  >
                    <div className={`w-2 h-2 rounded-full mt-2 flex-shrink-0 ${
                      notification.type === 'success' ? 'bg-green-500' :
                      notification.type === 'error' ? 'bg-red-500' :
                      notification.type === 'warning' ? 'bg-yellow-500' : 'bg-blue-500'
                    }`} />
                    <div className="flex-1 min-w-0">
                      <p className="font-medium text-sm text-gray-900">
                        {notification.title}
                      </p>
                      <p className="text-xs text-gray-500 mt-1">
                        {notification.message}
                      </p>
                      <p className="text-xs text-gray-400 mt-1 flex items-center">
                        <Clock className="w-3 h-3 mr-1" />
                        {formatTime(notification.timestamp)}
                      </p>
                    </div>
                  </DropdownMenuItem>
                ))}
              </div>
            )}
          </DropdownMenuContent>
        </DropdownMenu>

        {/* Menú de usuario */}
        <DropdownMenu>
          <DropdownMenuTrigger asChild>
            <Button variant="ghost" size="sm" className="p-2">
              <User className="w-4 h-4" />
            </Button>
          </DropdownMenuTrigger>
          <DropdownMenuContent align="end">
            <DropdownMenuLabel>Mi Cuenta</DropdownMenuLabel>
            <DropdownMenuSeparator />
            <DropdownMenuItem>
              <User className="w-4 h-4 mr-2" />
              Perfil
            </DropdownMenuItem>
            <DropdownMenuItem>
              <Settings className="w-4 h-4 mr-2" />
              Configuración
            </DropdownMenuItem>
            <DropdownMenuSeparator />
            <DropdownMenuItem className="text-red-600">
              <LogOut className="w-4 h-4 mr-2" />
              Cerrar Sesión
            </DropdownMenuItem>
          </DropdownMenuContent>
        </DropdownMenu>

        {/* Indicador de estado en tiempo real */}
        <div className="flex items-center space-x-2">
          <motion.div
            animate={{ 
              scale: systemStatus.overall_status === 'healthy' ? [1, 1.2, 1] : 1,
              opacity: systemStatus.overall_status === 'healthy' ? [1, 0.7, 1] : 1
            }}
            transition={{ 
              duration: 2, 
              repeat: systemStatus.overall_status === 'healthy' ? Infinity : 0 
            }}
            className={`w-2 h-2 rounded-full ${
              systemStatus.overall_status === 'healthy' ? 'bg-green-500' :
              systemStatus.overall_status === 'degraded' ? 'bg-yellow-500' : 'bg-red-500'
            }`}
            title={getSystemStatusText()}
          />
          <span className="text-xs text-gray-500 hidden lg:inline">
            Última actualización: {formatTime(systemStatus.last_update)}
          </span>
        </div>
      </div>
    </header>
  )
}

export default Header

