import React from 'react'
import { Link, useLocation } from 'react-router-dom'
import { motion, AnimatePresence } from 'framer-motion'
import { 
  Home, 
  Puzzle, 
  Settings, 
  Database, 
  BarChart3, 
  FileText,
  Activity,
  HelpCircle,
  User,
  ChevronRight
} from 'lucide-react'
import { useDashboard } from '../contexts/DashboardContext'

const Sidebar = ({ isOpen }) => {
  const location = useLocation()
  const { systemStatus, modules } = useDashboard()

  // Elementos del menú principal
  const mainMenuItems = [
    {
      id: 'dashboard',
      title: 'Dashboard',
      icon: Home,
      path: '/',
      description: 'Vista general del sistema'
    },
    {
      id: 'modules',
      title: 'Módulos',
      icon: Puzzle,
      path: '/modules',
      description: 'Gestión de módulos',
      children: [
        {
          id: 'file_explorer',
          title: 'Explorador de Archivos',
          icon: Database,
          path: '/modules/file_explorer',
          status: systemStatus.modules_status?.file_explorer || 'offline'
        },
        {
          id: 'data_analysis',
          title: 'Análisis Estadístico',
          icon: BarChart3,
          path: '/modules/data_analysis',
          status: systemStatus.modules_status?.data_analysis || 'offline'
        },
        {
          id: 'report_generator',
          title: 'Generador de Informes',
          icon: FileText,
          path: '/modules/report_generator',
          status: systemStatus.modules_status?.report_generator || 'offline'
        }
      ]
    },
    {
      id: 'system',
      title: 'Sistema',
      icon: Settings,
      path: '/system',
      description: 'Configuración y monitoreo',
      children: [
        {
          id: 'status',
          title: 'Estado',
          icon: Activity,
          path: '/system/status'
        },
        {
          id: 'settings',
          title: 'Configuración',
          icon: Settings,
          path: '/system/settings'
        }
      ]
    }
  ]

  // Elementos del menú inferior
  const bottomMenuItems = [
    {
      id: 'help',
      title: 'Ayuda',
      icon: HelpCircle,
      path: '/help'
    },
    {
      id: 'profile',
      title: 'Perfil',
      icon: User,
      path: '/profile'
    }
  ]

  const isActivePath = (path) => {
    if (path === '/') {
      return location.pathname === '/'
    }
    return location.pathname.startsWith(path)
  }

  const getStatusColor = (status) => {
    switch (status) {
      case 'online':
        return 'bg-green-500'
      case 'offline':
        return 'bg-red-500'
      case 'warning':
        return 'bg-yellow-500'
      default:
        return 'bg-gray-400'
    }
  }

  const MenuItem = ({ item, level = 0 }) => {
    const isActive = isActivePath(item.path)
    const hasChildren = item.children && item.children.length > 0
    const [isExpanded, setIsExpanded] = React.useState(isActive)

    React.useEffect(() => {
      if (isActive) {
        setIsExpanded(true)
      }
    }, [isActive])

    return (
      <div className="mb-1">
        <Link
          to={item.path}
          onClick={() => hasChildren && setIsExpanded(!isExpanded)}
          className={`
            flex items-center w-full px-3 py-2.5 rounded-lg transition-all duration-200
            ${level > 0 ? 'ml-4 pl-6' : ''}
            ${isActive 
              ? 'bg-blue-100 text-blue-700 border-r-2 border-blue-500' 
              : 'text-gray-600 hover:bg-gray-100 hover:text-gray-900'
            }
          `}
        >
          <item.icon className={`w-5 h-5 ${isOpen ? 'mr-3' : ''} flex-shrink-0`} />
          
          <AnimatePresence>
            {isOpen && (
              <motion.div
                initial={{ opacity: 0, width: 0 }}
                animate={{ opacity: 1, width: 'auto' }}
                exit={{ opacity: 0, width: 0 }}
                className="flex items-center justify-between w-full"
              >
                <div className="flex-1">
                  <span className="font-medium">{item.title}</span>
                  {item.description && level === 0 && (
                    <p className="text-xs text-gray-500 mt-0.5">{item.description}</p>
                  )}
                </div>
                
                {/* Indicador de estado para módulos */}
                {item.status && (
                  <div className={`w-2 h-2 rounded-full ${getStatusColor(item.status)} ml-2`} />
                )}
                
                {/* Flecha para elementos con hijos */}
                {hasChildren && (
                  <ChevronRight 
                    className={`w-4 h-4 ml-2 transition-transform duration-200 ${
                      isExpanded ? 'rotate-90' : ''
                    }`} 
                  />
                )}
              </motion.div>
            )}
          </AnimatePresence>
        </Link>

        {/* Elementos hijos */}
        <AnimatePresence>
          {hasChildren && isExpanded && isOpen && (
            <motion.div
              initial={{ opacity: 0, height: 0 }}
              animate={{ opacity: 1, height: 'auto' }}
              exit={{ opacity: 0, height: 0 }}
              className="mt-1"
            >
              {item.children.map((child) => (
                <MenuItem key={child.id} item={child} level={level + 1} />
              ))}
            </motion.div>
          )}
        </AnimatePresence>
      </div>
    )
  }

  return (
    <motion.div
      initial={false}
      animate={{ width: isOpen ? 256 : 64 }}
      transition={{ duration: 0.3, ease: "easeInOut" }}
      className="fixed left-0 top-0 h-full bg-white border-r border-gray-200 shadow-lg z-30 flex flex-col"
    >
      {/* Header del sidebar */}
      <div className="p-4 border-b border-gray-200">
        <div className="flex items-center">
          <div className="w-8 h-8 bg-gradient-to-r from-blue-500 to-orange-500 rounded-lg flex items-center justify-center flex-shrink-0">
            <span className="text-white font-bold text-sm">DT</span>
          </div>
          
          <AnimatePresence>
            {isOpen && (
              <motion.div
                initial={{ opacity: 0, x: -10 }}
                animate={{ opacity: 1, x: 0 }}
                exit={{ opacity: 0, x: -10 }}
                className="ml-3"
              >
                <h2 className="font-bold text-gray-900">Dashboard Tesis Pro</h2>
                <p className="text-xs text-gray-500">v2.0.0</p>
              </motion.div>
            )}
          </AnimatePresence>
        </div>
      </div>

      {/* Navegación principal */}
      <nav className="flex-1 p-4 overflow-y-auto">
        <div className="space-y-2">
          {mainMenuItems.map((item) => (
            <MenuItem key={item.id} item={item} />
          ))}
        </div>
      </nav>

      {/* Estado del sistema (compacto) */}
      <div className="p-4 border-t border-gray-200">
        <AnimatePresence>
          {isOpen ? (
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              className="bg-gray-50 rounded-lg p-3"
            >
              <div className="flex items-center justify-between mb-2">
                <span className="text-sm font-medium text-gray-700">Estado del Sistema</span>
                <div className={`w-2 h-2 rounded-full ${
                  systemStatus.overall_status === 'healthy' ? 'bg-green-500' :
                  systemStatus.overall_status === 'degraded' ? 'bg-yellow-500' : 'bg-red-500'
                }`} />
              </div>
              <div className="text-xs text-gray-500">
                Módulos activos: {Object.values(systemStatus.modules_status || {}).filter(s => s === 'online').length}/3
              </div>
            </motion.div>
          ) : (
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              className="flex justify-center"
            >
              <div className={`w-3 h-3 rounded-full ${
                systemStatus.overall_status === 'healthy' ? 'bg-green-500' :
                systemStatus.overall_status === 'degraded' ? 'bg-yellow-500' : 'bg-red-500'
              }`} />
            </motion.div>
          )}
        </AnimatePresence>
      </div>

      {/* Menú inferior */}
      <div className="p-4 border-t border-gray-200">
        <div className="space-y-1">
          {bottomMenuItems.map((item) => (
            <MenuItem key={item.id} item={item} />
          ))}
        </div>
      </div>
    </motion.div>
  )
}

export default Sidebar

