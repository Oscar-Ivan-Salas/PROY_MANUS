import React from 'react'
import { motion } from 'framer-motion'
import { Loader2, Database, BarChart3, FileText } from 'lucide-react'

const LoadingScreen = () => {
  const modules = [
    { icon: Database, name: 'Explorador de Archivos', delay: 0.2 },
    { icon: BarChart3, name: 'Análisis Estadístico', delay: 0.4 },
    { icon: FileText, name: 'Generador de Informes', delay: 0.6 }
  ]

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 via-white to-orange-50 flex items-center justify-center">
      <div className="text-center">
        {/* Logo y título principal */}
        <motion.div
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
          className="mb-8"
        >
          <div className="w-20 h-20 mx-auto mb-4 bg-gradient-to-r from-blue-500 to-orange-500 rounded-2xl flex items-center justify-center">
            <motion.div
              animate={{ rotate: 360 }}
              transition={{ duration: 2, repeat: Infinity, ease: "linear" }}
            >
              <Loader2 className="w-10 h-10 text-white" />
            </motion.div>
          </div>
          
          <h1 className="text-4xl font-bold bg-gradient-to-r from-blue-600 to-orange-600 bg-clip-text text-transparent">
            Dashboard Tesis Pro
          </h1>
          <p className="text-gray-600 mt-2 text-lg">
            Sistema Integrado de Análisis y Gestión
          </p>
        </motion.div>

        {/* Indicador de progreso */}
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 0.3, duration: 0.6 }}
          className="mb-8"
        >
          <div className="w-64 h-2 bg-gray-200 rounded-full mx-auto overflow-hidden">
            <motion.div
              initial={{ width: 0 }}
              animate={{ width: '100%' }}
              transition={{ duration: 2, ease: "easeInOut" }}
              className="h-full bg-gradient-to-r from-blue-500 to-orange-500 rounded-full"
            />
          </div>
          <p className="text-sm text-gray-500 mt-2">Inicializando módulos...</p>
        </motion.div>

        {/* Módulos cargando */}
        <div className="space-y-4">
          {modules.map((module, index) => (
            <motion.div
              key={module.name}
              initial={{ opacity: 0, x: -20 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ delay: module.delay, duration: 0.5 }}
              className="flex items-center justify-center space-x-3 text-gray-600"
            >
              <module.icon className="w-5 h-5" />
              <span className="text-sm">{module.name}</span>
              <motion.div
                animate={{ rotate: 360 }}
                transition={{ 
                  duration: 1.5, 
                  repeat: Infinity, 
                  ease: "linear",
                  delay: module.delay 
                }}
              >
                <Loader2 className="w-4 h-4" />
              </motion.div>
            </motion.div>
          ))}
        </div>

        {/* Información adicional */}
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 1, duration: 0.6 }}
          className="mt-12 text-xs text-gray-400"
        >
          <p>Versión 2.0.0 • Desarrollado para investigación académica</p>
        </motion.div>
      </div>
    </div>
  )
}

export default LoadingScreen

