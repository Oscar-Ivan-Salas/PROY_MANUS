#!/usr/bin/env python3
"""
Dashboard Tesis Pro - Rutas de Gestión de Módulos
Endpoints para comunicación y control de módulos
"""

from flask import Blueprint, jsonify, request, redirect
import requests
import json
from datetime import datetime
import subprocess
import os
import signal

modules_bp = Blueprint('modules', __name__)

# Configuración de módulos
MODULES_CONFIG = {
    'file_explorer': {
        'name': 'Explorador de Archivos Profesional',
        'description': 'Gestión avanzada de archivos con FileBrowser',
        'port': 8058,
        'api_port': 8060,
        'start_script': '../modules/file_explorer/start_filebrowser.sh',
        'health_endpoint': '/api/status',
        'icon': '📁',
        'category': 'storage'
    },
    'data_analysis': {
        'name': 'Análisis Estadístico Interactivo',
        'description': 'Análisis avanzado con Streamlit y Python',
        'port': 8050,
        'start_script': '../modules/data_analysis/start_analysis_dashboard.sh',
        'health_endpoint': '/',
        'icon': '📊',
        'category': 'analytics'
    },
    'report_generator': {
        'name': 'Generador de Informes Profesionales',
        'description': 'Reportes en múltiples formatos con plantillas',
        'port': 8070,
        'start_script': '../modules/report_generator/start_report_generator.sh',
        'health_endpoint': '/',
        'icon': '📄',
        'category': 'reporting'
    }
}

# Estado de procesos (en memoria)
MODULE_PROCESSES = {}

@modules_bp.route('/')
def list_modules():
    """Listar todos los módulos disponibles"""
    
    modules_list = []
    
    for module_id, config in MODULES_CONFIG.items():
        module_info = config.copy()
        module_info['id'] = module_id
        module_info['status'] = get_module_status(module_id)
        module_info['url'] = f"http://localhost:{config['port']}"
        
        # Obtener estadísticas adicionales si está disponible
        if module_info['status']['online']:
            module_info['stats'] = get_module_stats(module_id)
        
        modules_list.append(module_info)
    
    return jsonify({
        'modules': modules_list,
        'total_count': len(modules_list),
        'online_count': sum(1 for m in modules_list if m['status']['online']),
        'categories': list(set(config['category'] for config in MODULES_CONFIG.values()))
    })

@modules_bp.route('/<module_id>')
def get_module_info(module_id):
    """Obtener información detallada de un módulo"""
    
    if module_id not in MODULES_CONFIG:
        return jsonify({'error': 'Módulo no encontrado'}), 404
    
    config = MODULES_CONFIG[module_id].copy()
    config['id'] = module_id
    config['status'] = get_module_status(module_id)
    config['url'] = f"http://localhost:{config['port']}"
    
    # Información adicional
    if config['status']['online']:
        config['stats'] = get_module_stats(module_id)
        config['endpoints'] = get_module_endpoints(module_id)
    
    return jsonify(config)

@modules_bp.route('/<module_id>/status')
def module_status(module_id):
    """Obtener estado detallado de un módulo"""
    
    if module_id not in MODULES_CONFIG:
        return jsonify({'error': 'Módulo no encontrado'}), 404
    
    status = get_module_status(module_id)
    
    # Agregar información adicional
    status['module_id'] = module_id
    status['timestamp'] = datetime.now().isoformat()
    
    if status['online']:
        status['stats'] = get_module_stats(module_id)
    
    return jsonify(status)

@modules_bp.route('/<module_id>/start', methods=['POST'])
def start_module(module_id):
    """Iniciar un módulo"""
    
    if module_id not in MODULES_CONFIG:
        return jsonify({'error': 'Módulo no encontrado'}), 404
    
    config = MODULES_CONFIG[module_id]
    
    # Verificar si ya está ejecutándose
    status = get_module_status(module_id)
    if status['online']:
        return jsonify({
            'success': True,
            'message': f'El módulo {module_id} ya está ejecutándose',
            'status': status
        })
    
    try:
        # Ejecutar script de inicio
        script_path = os.path.join(os.path.dirname(__file__), config['start_script'])
        
        if not os.path.exists(script_path):
            return jsonify({
                'success': False,
                'error': f'Script de inicio no encontrado: {script_path}'
            }), 500
        
        # Iniciar proceso en background
        process = subprocess.Popen(
            ['bash', script_path],
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            preexec_fn=os.setsid  # Crear nuevo grupo de procesos
        )
        
        # Guardar referencia del proceso
        MODULE_PROCESSES[module_id] = process
        
        return jsonify({
            'success': True,
            'message': f'Iniciando módulo {module_id}...',
            'process_id': process.pid,
            'note': 'El módulo puede tardar unos segundos en estar disponible'
        })
        
    except Exception as e:
        return jsonify({
            'success': False,
            'error': f'Error al iniciar módulo: {str(e)}'
        }), 500

@modules_bp.route('/<module_id>/stop', methods=['POST'])
def stop_module(module_id):
    """Detener un módulo"""
    
    if module_id not in MODULES_CONFIG:
        return jsonify({'error': 'Módulo no encontrado'}), 404
    
    try:
        # Intentar detener proceso conocido
        if module_id in MODULE_PROCESSES:
            process = MODULE_PROCESSES[module_id]
            
            # Terminar grupo de procesos
            os.killpg(os.getpgid(process.pid), signal.SIGTERM)
            
            # Esperar un poco y verificar
            process.wait(timeout=5)
            del MODULE_PROCESSES[module_id]
        
        # Verificar que realmente se detuvo
        status = get_module_status(module_id)
        
        return jsonify({
            'success': not status['online'],
            'message': f'Módulo {module_id} {"detenido" if not status["online"] else "aún ejecutándose"}',
            'status': status
        })
        
    except subprocess.TimeoutExpired:
        # Forzar terminación
        try:
            os.killpg(os.getpgid(process.pid), signal.SIGKILL)
            del MODULE_PROCESSES[module_id]
        except:
            pass
        
        return jsonify({
            'success': True,
            'message': f'Módulo {module_id} terminado forzosamente'
        })
        
    except Exception as e:
        return jsonify({
            'success': False,
            'error': f'Error al detener módulo: {str(e)}'
        }), 500

@modules_bp.route('/<module_id>/restart', methods=['POST'])
def restart_module(module_id):
    """Reiniciar un módulo"""
    
    if module_id not in MODULES_CONFIG:
        return jsonify({'error': 'Módulo no encontrado'}), 404
    
    # Primero detener
    stop_result = stop_module(module_id)
    
    if not stop_result[0].get_json().get('success', False):
        return jsonify({
            'success': False,
            'error': 'No se pudo detener el módulo para reiniciar'
        }), 500
    
    # Esperar un momento
    import time
    time.sleep(2)
    
    # Luego iniciar
    start_result = start_module(module_id)
    
    return jsonify({
        'success': True,
        'message': f'Módulo {module_id} reiniciado',
        'start_result': start_result[0].get_json()
    })

@modules_bp.route('/<module_id>/proxy/<path:endpoint>')
def proxy_to_module(module_id, endpoint):
    """Proxy para comunicación con módulos"""
    
    if module_id not in MODULES_CONFIG:
        return jsonify({'error': 'Módulo no encontrado'}), 404
    
    config = MODULES_CONFIG[module_id]
    
    # Determinar puerto correcto
    if module_id == 'file_explorer' and endpoint.startswith('api/'):
        target_port = config['api_port']
    else:
        target_port = config['port']
    
    target_url = f"http://localhost:{target_port}/{endpoint}"
    
    try:
        # Reenviar petición
        if request.method == 'GET':
            response = requests.get(
                target_url, 
                params=request.args,
                headers={'User-Agent': 'Dashboard-Tesis-Pro'},
                timeout=30
            )
        elif request.method == 'POST':
            response = requests.post(
                target_url,
                json=request.json,
                headers={'User-Agent': 'Dashboard-Tesis-Pro'},
                timeout=30
            )
        else:
            return jsonify({'error': 'Método no soportado'}), 405
        
        # Devolver respuesta
        try:
            return jsonify(response.json()), response.status_code
        except:
            return response.text, response.status_code
    
    except requests.exceptions.RequestException as e:
        return jsonify({
            'error': f'Error de comunicación con {module_id}',
            'details': str(e)
        }), 503

@modules_bp.route('/<module_id>/redirect')
def redirect_to_module(module_id):
    """Redirigir directamente al módulo"""
    
    if module_id not in MODULES_CONFIG:
        return jsonify({'error': 'Módulo no encontrado'}), 404
    
    config = MODULES_CONFIG[module_id]
    module_url = f"http://localhost:{config['port']}"
    
    return redirect(module_url)

@modules_bp.route('/health')
def modules_health():
    """Estado de salud de todos los módulos"""
    
    health_report = {
        'timestamp': datetime.now().isoformat(),
        'overall_status': 'healthy',
        'modules': {}
    }
    
    offline_count = 0
    
    for module_id in MODULES_CONFIG.keys():
        status = get_module_status(module_id)
        health_report['modules'][module_id] = status
        
        if not status['online']:
            offline_count += 1
    
    # Determinar estado general
    total_modules = len(MODULES_CONFIG)
    if offline_count == 0:
        health_report['overall_status'] = 'healthy'
    elif offline_count < total_modules:
        health_report['overall_status'] = 'degraded'
    else:
        health_report['overall_status'] = 'critical'
    
    health_report['summary'] = {
        'total_modules': total_modules,
        'online_modules': total_modules - offline_count,
        'offline_modules': offline_count
    }
    
    return jsonify(health_report)

@modules_bp.route('/categories')
def module_categories():
    """Obtener categorías de módulos"""
    
    categories = {}
    
    for module_id, config in MODULES_CONFIG.items():
        category = config['category']
        
        if category not in categories:
            categories[category] = {
                'name': category.title(),
                'modules': [],
                'online_count': 0,
                'total_count': 0
            }
        
        module_info = {
            'id': module_id,
            'name': config['name'],
            'icon': config['icon'],
            'online': get_module_status(module_id)['online']
        }
        
        categories[category]['modules'].append(module_info)
        categories[category]['total_count'] += 1
        
        if module_info['online']:
            categories[category]['online_count'] += 1
    
    return jsonify(categories)

# Funciones auxiliares
def get_module_status(module_id):
    """Obtener estado de un módulo"""
    
    if module_id not in MODULES_CONFIG:
        return {'online': False, 'error': 'Módulo no configurado'}
    
    config = MODULES_CONFIG[module_id]
    
    try:
        # Determinar endpoint de salud
        if module_id == 'file_explorer':
            health_url = f"http://localhost:{config['api_port']}{config['health_endpoint']}"
        else:
            health_url = f"http://localhost:{config['port']}{config['health_endpoint']}"
        
        response = requests.get(health_url, timeout=5)
        
        return {
            'online': response.status_code == 200,
            'status_code': response.status_code,
            'response_time': response.elapsed.total_seconds(),
            'last_check': datetime.now().isoformat()
        }
        
    except requests.exceptions.RequestException as e:
        return {
            'online': False,
            'error': str(e),
            'last_check': datetime.now().isoformat()
        }

def get_module_stats(module_id):
    """Obtener estadísticas de un módulo"""
    
    if module_id not in MODULES_CONFIG:
        return {}
    
    try:
        if module_id == 'file_explorer':
            # Estadísticas del explorador de archivos
            response = requests.get('http://localhost:8060/api/stats', timeout=5)
            if response.status_code == 200:
                return response.json()
        
        # Para otros módulos, estadísticas básicas
        return {
            'uptime': 'unknown',
            'requests_count': 'unknown',
            'last_activity': datetime.now().isoformat()
        }
        
    except:
        return {}

def get_module_endpoints(module_id):
    """Obtener endpoints disponibles de un módulo"""
    
    endpoints = {
        'file_explorer': [
            {'path': '/api/status', 'method': 'GET', 'description': 'Estado del servicio'},
            {'path': '/api/files', 'method': 'GET', 'description': 'Listar archivos'},
            {'path': '/api/upload', 'method': 'POST', 'description': 'Subir archivo'},
            {'path': '/api/stats', 'method': 'GET', 'description': 'Estadísticas'}
        ],
        'data_analysis': [
            {'path': '/', 'method': 'GET', 'description': 'Interfaz principal'},
            {'path': '/health', 'method': 'GET', 'description': 'Estado de salud'}
        ],
        'report_generator': [
            {'path': '/', 'method': 'GET', 'description': 'Interfaz principal'},
            {'path': '/health', 'method': 'GET', 'description': 'Estado de salud'}
        ]
    }
    
    return endpoints.get(module_id, [])

