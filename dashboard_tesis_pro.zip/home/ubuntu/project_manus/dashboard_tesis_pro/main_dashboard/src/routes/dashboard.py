#!/usr/bin/env python3
"""
Dashboard Tesis Pro - Rutas del Dashboard Principal
Endpoints para gestión del dashboard central
"""

from flask import Blueprint, jsonify, request
import requests
import json
from datetime import datetime, timedelta
import os

dashboard_bp = Blueprint('dashboard', __name__)

# Configuración de métricas y estadísticas
METRICS_CACHE = {
    'last_update': None,
    'data': {}
}

@dashboard_bp.route('/overview')
def dashboard_overview():
    """Vista general del dashboard con métricas principales"""
    
    overview_data = {
        'timestamp': datetime.now().isoformat(),
        'system_status': get_system_status(),
        'quick_stats': get_quick_stats(),
        'recent_activity': get_recent_activity(),
        'module_health': get_module_health()
    }
    
    return jsonify(overview_data)

@dashboard_bp.route('/metrics')
def dashboard_metrics():
    """Métricas detalladas del sistema"""
    
    # Verificar cache (actualizar cada 5 minutos)
    now = datetime.now()
    if (METRICS_CACHE['last_update'] is None or 
        now - METRICS_CACHE['last_update'] > timedelta(minutes=5)):
        
        METRICS_CACHE['data'] = collect_system_metrics()
        METRICS_CACHE['last_update'] = now
    
    return jsonify(METRICS_CACHE['data'])

@dashboard_bp.route('/modules/status')
def modules_status():
    """Estado detallado de todos los módulos"""
    
    modules_status = {}
    
    # Módulo 1: Explorador de Archivos
    try:
        response = requests.get('http://localhost:8060/api/status', timeout=3)
        if response.status_code == 200:
            file_stats = requests.get('http://localhost:8060/api/stats', timeout=3)
            modules_status['file_explorer'] = {
                'status': 'online',
                'response_time': response.elapsed.total_seconds(),
                'stats': file_stats.json() if file_stats.status_code == 200 else {},
                'last_check': datetime.now().isoformat()
            }
        else:
            modules_status['file_explorer'] = {
                'status': 'error',
                'error': f'HTTP {response.status_code}',
                'last_check': datetime.now().isoformat()
            }
    except Exception as e:
        modules_status['file_explorer'] = {
            'status': 'offline',
            'error': str(e),
            'last_check': datetime.now().isoformat()
        }
    
    # Módulo 2: Análisis Estadístico
    try:
        response = requests.get('http://localhost:8050', timeout=3)
        modules_status['data_analysis'] = {
            'status': 'online' if response.status_code == 200 else 'error',
            'response_time': response.elapsed.total_seconds(),
            'last_check': datetime.now().isoformat()
        }
    except Exception as e:
        modules_status['data_analysis'] = {
            'status': 'offline',
            'error': str(e),
            'last_check': datetime.now().isoformat()
        }
    
    # Módulo 3: Generador de Informes
    try:
        response = requests.get('http://localhost:8070', timeout=3)
        modules_status['report_generator'] = {
            'status': 'online' if response.status_code == 200 else 'error',
            'response_time': response.elapsed.total_seconds(),
            'last_check': datetime.now().isoformat()
        }
    except Exception as e:
        modules_status['report_generator'] = {
            'status': 'offline',
            'error': str(e),
            'last_check': datetime.now().isoformat()
        }
    
    return jsonify(modules_status)

@dashboard_bp.route('/quick-actions')
def quick_actions():
    """Acciones rápidas disponibles"""
    
    actions = [
        {
            'id': 'upload_file',
            'title': 'Subir Archivo',
            'description': 'Cargar nuevos datos para análisis',
            'icon': '📤',
            'module': 'file_explorer',
            'url': '/modules/file_explorer',
            'enabled': is_module_online('file_explorer')
        },
        {
            'id': 'quick_analysis',
            'title': 'Análisis Rápido',
            'description': 'Ejecutar análisis estadístico básico',
            'icon': '⚡',
            'module': 'data_analysis',
            'url': '/modules/data_analysis',
            'enabled': is_module_online('data_analysis')
        },
        {
            'id': 'generate_report',
            'title': 'Generar Reporte',
            'description': 'Crear reporte ejecutivo automático',
            'icon': '📄',
            'module': 'report_generator',
            'url': '/modules/report_generator',
            'enabled': is_module_online('report_generator')
        },
        {
            'id': 'system_status',
            'title': 'Estado del Sistema',
            'description': 'Verificar salud de todos los módulos',
            'icon': '🔧',
            'module': 'dashboard',
            'url': '/system/status',
            'enabled': True
        }
    ]
    
    return jsonify(actions)

@dashboard_bp.route('/navigation')
def navigation_menu():
    """Menú de navegación dinámico"""
    
    navigation = {
        'main_sections': [
            {
                'id': 'dashboard',
                'title': 'Dashboard',
                'icon': '🏠',
                'url': '/',
                'active': True
            },
            {
                'id': 'modules',
                'title': 'Módulos',
                'icon': '🧩',
                'url': '/modules',
                'children': [
                    {
                        'id': 'file_explorer',
                        'title': 'Explorador de Archivos',
                        'icon': '📁',
                        'url': '/modules/file_explorer',
                        'status': 'online' if is_module_online('file_explorer') else 'offline'
                    },
                    {
                        'id': 'data_analysis',
                        'title': 'Análisis Estadístico',
                        'icon': '📊',
                        'url': '/modules/data_analysis',
                        'status': 'online' if is_module_online('data_analysis') else 'offline'
                    },
                    {
                        'id': 'report_generator',
                        'title': 'Generador de Informes',
                        'icon': '📄',
                        'url': '/modules/report_generator',
                        'status': 'online' if is_module_online('report_generator') else 'offline'
                    }
                ]
            },
            {
                'id': 'system',
                'title': 'Sistema',
                'icon': '⚙️',
                'url': '/system',
                'children': [
                    {
                        'id': 'status',
                        'title': 'Estado',
                        'icon': '📊',
                        'url': '/system/status'
                    },
                    {
                        'id': 'logs',
                        'title': 'Logs',
                        'icon': '📝',
                        'url': '/system/logs'
                    },
                    {
                        'id': 'settings',
                        'title': 'Configuración',
                        'icon': '⚙️',
                        'url': '/system/settings'
                    }
                ]
            }
        ],
        'user_menu': [
            {
                'id': 'profile',
                'title': 'Perfil',
                'icon': '👤',
                'url': '/profile'
            },
            {
                'id': 'help',
                'title': 'Ayuda',
                'icon': '❓',
                'url': '/help'
            },
            {
                'id': 'about',
                'title': 'Acerca de',
                'icon': 'ℹ️',
                'url': '/about'
            }
        ]
    }
    
    return jsonify(navigation)

@dashboard_bp.route('/widgets')
def dashboard_widgets():
    """Widgets disponibles para el dashboard"""
    
    widgets = [
        {
            'id': 'system_health',
            'title': 'Salud del Sistema',
            'type': 'status',
            'size': 'small',
            'data': get_system_health_widget(),
            'refresh_interval': 30
        },
        {
            'id': 'module_status',
            'title': 'Estado de Módulos',
            'type': 'grid',
            'size': 'medium',
            'data': get_module_status_widget(),
            'refresh_interval': 60
        },
        {
            'id': 'recent_files',
            'title': 'Archivos Recientes',
            'type': 'list',
            'size': 'medium',
            'data': get_recent_files_widget(),
            'refresh_interval': 120
        },
        {
            'id': 'quick_stats',
            'title': 'Estadísticas Rápidas',
            'type': 'metrics',
            'size': 'large',
            'data': get_quick_stats_widget(),
            'refresh_interval': 300
        }
    ]
    
    return jsonify(widgets)

# Funciones auxiliares
def get_system_status():
    """Obtener estado general del sistema"""
    modules_online = 0
    total_modules = 3
    
    if is_module_online('file_explorer'):
        modules_online += 1
    if is_module_online('data_analysis'):
        modules_online += 1
    if is_module_online('report_generator'):
        modules_online += 1
    
    if modules_online == total_modules:
        status = 'healthy'
    elif modules_online > 0:
        status = 'degraded'
    else:
        status = 'critical'
    
    return {
        'status': status,
        'modules_online': modules_online,
        'total_modules': total_modules,
        'uptime': get_system_uptime()
    }

def get_quick_stats():
    """Obtener estadísticas rápidas"""
    stats = {
        'total_files': 0,
        'total_analyses': 0,
        'total_reports': 0,
        'system_load': get_system_load()
    }
    
    # Obtener estadísticas del explorador de archivos
    try:
        response = requests.get('http://localhost:8060/api/stats', timeout=3)
        if response.status_code == 200:
            file_stats = response.json()
            stats['total_files'] = file_stats.get('total_files', 0)
    except:
        pass
    
    return stats

def get_recent_activity():
    """Obtener actividad reciente"""
    # Placeholder - en implementación real obtendría de logs
    return [
        {
            'timestamp': datetime.now().isoformat(),
            'action': 'Sistema iniciado',
            'module': 'dashboard',
            'user': 'system'
        }
    ]

def get_module_health():
    """Obtener salud de módulos"""
    health = {}
    
    modules = ['file_explorer', 'data_analysis', 'report_generator']
    for module in modules:
        health[module] = {
            'status': 'online' if is_module_online(module) else 'offline',
            'last_check': datetime.now().isoformat()
        }
    
    return health

def is_module_online(module_name):
    """Verificar si un módulo está en línea"""
    try:
        if module_name == 'file_explorer':
            response = requests.get('http://localhost:8060/api/status', timeout=2)
        elif module_name == 'data_analysis':
            response = requests.get('http://localhost:8050', timeout=2)
        elif module_name == 'report_generator':
            response = requests.get('http://localhost:8070', timeout=2)
        else:
            return False
        
        return response.status_code == 200
    except:
        return False

def collect_system_metrics():
    """Recopilar métricas del sistema"""
    return {
        'timestamp': datetime.now().isoformat(),
        'cpu_usage': 0,  # Placeholder
        'memory_usage': 0,  # Placeholder
        'disk_usage': 0,  # Placeholder
        'network_io': 0,  # Placeholder
        'modules_performance': {
            'file_explorer': get_module_performance('file_explorer'),
            'data_analysis': get_module_performance('data_analysis'),
            'report_generator': get_module_performance('report_generator')
        }
    }

def get_module_performance(module_name):
    """Obtener rendimiento de un módulo"""
    try:
        start_time = datetime.now()
        
        if module_name == 'file_explorer':
            response = requests.get('http://localhost:8060/api/status', timeout=5)
        elif module_name == 'data_analysis':
            response = requests.get('http://localhost:8050', timeout=5)
        elif module_name == 'report_generator':
            response = requests.get('http://localhost:8070', timeout=5)
        else:
            return {'status': 'unknown', 'response_time': 0}
        
        response_time = (datetime.now() - start_time).total_seconds()
        
        return {
            'status': 'online' if response.status_code == 200 else 'error',
            'response_time': response_time,
            'last_check': datetime.now().isoformat()
        }
    except Exception as e:
        return {
            'status': 'offline',
            'error': str(e),
            'response_time': 0,
            'last_check': datetime.now().isoformat()
        }

def get_system_uptime():
    """Obtener tiempo de actividad del sistema"""
    # Placeholder - en implementación real calcularía desde inicio
    return "00:00:00"

def get_system_load():
    """Obtener carga del sistema"""
    # Placeholder - en implementación real obtendría métricas reales
    return 0.0

# Funciones para widgets
def get_system_health_widget():
    """Datos para widget de salud del sistema"""
    return get_system_status()

def get_module_status_widget():
    """Datos para widget de estado de módulos"""
    return get_module_health()

def get_recent_files_widget():
    """Datos para widget de archivos recientes"""
    try:
        response = requests.get('http://localhost:8060/api/files/recent', timeout=3)
        if response.status_code == 200:
            return response.json()
    except:
        pass
    
    return {'files': [], 'count': 0}

def get_quick_stats_widget():
    """Datos para widget de estadísticas rápidas"""
    return get_quick_stats()

