#!/usr/bin/env python3
"""
Dashboard Tesis Pro - Rutas de Gestión del Sistema
Endpoints para monitoreo, configuración y administración del sistema
"""

from flask import Blueprint, jsonify, request, send_file
import json
import os
import psutil
import platform
from datetime import datetime, timedelta
import subprocess
import logging
from typing import Dict, Any

system_bp = Blueprint('system', __name__)

# Configuración de logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

# Configuración del sistema
SYSTEM_CONFIG_FILE = os.path.join(os.path.dirname(__file__), '..', 'config', 'system_config.json')
LOG_FILE = os.path.join(os.path.dirname(__file__), '..', 'logs', 'dashboard.log')

# Configuración por defecto
DEFAULT_CONFIG = {
    'system': {
        'name': 'Dashboard Tesis Pro',
        'version': '2.0.0',
        'environment': 'development',
        'debug': True,
        'auto_start_modules': True,
        'monitoring_interval': 60,
        'log_level': 'INFO'
    },
    'security': {
        'enable_auth': False,
        'session_timeout': 3600,
        'max_login_attempts': 5,
        'require_https': False
    },
    'performance': {
        'cache_enabled': True,
        'cache_timeout': 300,
        'max_concurrent_requests': 100,
        'request_timeout': 30
    },
    'modules': {
        'file_explorer': {
            'enabled': True,
            'auto_start': True,
            'max_file_size': '100MB',
            'allowed_extensions': ['csv', 'xlsx', 'json', 'txt']
        },
        'data_analysis': {
            'enabled': True,
            'auto_start': True,
            'max_dataset_size': '1GB',
            'cache_results': True
        },
        'report_generator': {
            'enabled': True,
            'auto_start': True,
            'max_report_size': '50MB',
            'default_format': 'html'
        }
    }
}

@system_bp.route('/info')
def system_info():
    """Información general del sistema"""
    
    try:
        # Información del sistema operativo
        system_info = {
            'os': {
                'name': platform.system(),
                'version': platform.version(),
                'architecture': platform.architecture()[0],
                'processor': platform.processor(),
                'hostname': platform.node()
            },
            'python': {
                'version': platform.python_version(),
                'implementation': platform.python_implementation(),
                'compiler': platform.python_compiler()
            },
            'hardware': {
                'cpu_count': psutil.cpu_count(),
                'cpu_freq': psutil.cpu_freq()._asdict() if psutil.cpu_freq() else None,
                'memory_total': psutil.virtual_memory().total,
                'disk_total': psutil.disk_usage('/').total
            },
            'dashboard': {
                'version': get_config()['system']['version'],
                'environment': get_config()['system']['environment'],
                'uptime': get_system_uptime(),
                'pid': os.getpid()
            }
        }
        
        return jsonify(system_info)
        
    except Exception as e:
        logger.error(f"Error obteniendo información del sistema: {str(e)}")
        return jsonify({'error': str(e)}), 500

@system_bp.route('/metrics')
def system_metrics():
    """Métricas de rendimiento del sistema"""
    
    try:
        # Métricas de CPU
        cpu_percent = psutil.cpu_percent(interval=1)
        cpu_times = psutil.cpu_times()._asdict()
        
        # Métricas de memoria
        memory = psutil.virtual_memory()._asdict()
        swap = psutil.swap_memory()._asdict()
        
        # Métricas de disco
        disk_usage = psutil.disk_usage('/')._asdict()
        disk_io = psutil.disk_io_counters()._asdict() if psutil.disk_io_counters() else {}
        
        # Métricas de red
        network_io = psutil.net_io_counters()._asdict() if psutil.net_io_counters() else {}
        
        # Procesos
        process_count = len(psutil.pids())
        
        metrics = {
            'timestamp': datetime.now().isoformat(),
            'cpu': {
                'percent': cpu_percent,
                'times': cpu_times,
                'count': psutil.cpu_count()
            },
            'memory': memory,
            'swap': swap,
            'disk': {
                'usage': disk_usage,
                'io': disk_io
            },
            'network': {
                'io': network_io
            },
            'processes': {
                'count': process_count
            },
            'load_average': os.getloadavg() if hasattr(os, 'getloadavg') else [0, 0, 0]
        }
        
        return jsonify(metrics)
        
    except Exception as e:
        logger.error(f"Error obteniendo métricas del sistema: {str(e)}")
        return jsonify({'error': str(e)}), 500

@system_bp.route('/health')
def system_health():
    """Estado de salud del sistema"""
    
    try:
        health_status = {
            'timestamp': datetime.now().isoformat(),
            'overall_status': 'healthy',
            'checks': {}
        }
        
        # Verificar CPU
        cpu_percent = psutil.cpu_percent(interval=1)
        health_status['checks']['cpu'] = {
            'status': 'healthy' if cpu_percent < 80 else 'warning' if cpu_percent < 95 else 'critical',
            'value': cpu_percent,
            'unit': 'percent'
        }
        
        # Verificar memoria
        memory = psutil.virtual_memory()
        memory_percent = memory.percent
        health_status['checks']['memory'] = {
            'status': 'healthy' if memory_percent < 80 else 'warning' if memory_percent < 95 else 'critical',
            'value': memory_percent,
            'unit': 'percent'
        }
        
        # Verificar disco
        disk = psutil.disk_usage('/')
        disk_percent = (disk.used / disk.total) * 100
        health_status['checks']['disk'] = {
            'status': 'healthy' if disk_percent < 80 else 'warning' if disk_percent < 95 else 'critical',
            'value': disk_percent,
            'unit': 'percent'
        }
        
        # Verificar módulos
        modules_health = check_modules_health()
        health_status['checks']['modules'] = modules_health
        
        # Determinar estado general
        critical_checks = [check for check in health_status['checks'].values() 
                          if isinstance(check, dict) and check.get('status') == 'critical']
        warning_checks = [check for check in health_status['checks'].values() 
                         if isinstance(check, dict) and check.get('status') == 'warning']
        
        if critical_checks:
            health_status['overall_status'] = 'critical'
        elif warning_checks:
            health_status['overall_status'] = 'warning'
        else:
            health_status['overall_status'] = 'healthy'
        
        return jsonify(health_status)
        
    except Exception as e:
        logger.error(f"Error verificando salud del sistema: {str(e)}")
        return jsonify({
            'overall_status': 'error',
            'error': str(e),
            'timestamp': datetime.now().isoformat()
        }), 500

@system_bp.route('/config')
def get_system_config():
    """Obtener configuración del sistema"""
    
    try:
        config = get_config()
        return jsonify(config)
    except Exception as e:
        logger.error(f"Error obteniendo configuración: {str(e)}")
        return jsonify({'error': str(e)}), 500

@system_bp.route('/config', methods=['POST'])
def update_system_config():
    """Actualizar configuración del sistema"""
    
    try:
        new_config = request.get_json()
        
        if not new_config:
            return jsonify({'error': 'Configuración no válida'}), 400
        
        # Validar configuración
        validation_result = validate_config(new_config)
        if not validation_result['valid']:
            return jsonify({
                'error': 'Configuración no válida',
                'details': validation_result['errors']
            }), 400
        
        # Guardar configuración
        save_config(new_config)
        
        logger.info("Configuración del sistema actualizada")
        
        return jsonify({
            'success': True,
            'message': 'Configuración actualizada correctamente',
            'config': new_config
        })
        
    except Exception as e:
        logger.error(f"Error actualizando configuración: {str(e)}")
        return jsonify({'error': str(e)}), 500

@system_bp.route('/logs')
def get_system_logs():
    """Obtener logs del sistema"""
    
    try:
        lines = request.args.get('lines', 100, type=int)
        level = request.args.get('level', 'all')
        
        logs = get_logs(lines, level)
        
        return jsonify({
            'logs': logs,
            'total_lines': len(logs),
            'timestamp': datetime.now().isoformat()
        })
        
    except Exception as e:
        logger.error(f"Error obteniendo logs: {str(e)}")
        return jsonify({'error': str(e)}), 500

@system_bp.route('/logs/download')
def download_logs():
    """Descargar archivo de logs"""
    
    try:
        if os.path.exists(LOG_FILE):
            return send_file(
                LOG_FILE,
                as_attachment=True,
                download_name=f"dashboard_logs_{datetime.now().strftime('%Y%m%d_%H%M%S')}.log"
            )
        else:
            return jsonify({'error': 'Archivo de logs no encontrado'}), 404
            
    except Exception as e:
        logger.error(f"Error descargando logs: {str(e)}")
        return jsonify({'error': str(e)}), 500

@system_bp.route('/backup', methods=['POST'])
def create_system_backup():
    """Crear respaldo del sistema"""
    
    try:
        backup_data = {
            'timestamp': datetime.now().isoformat(),
            'version': get_config()['system']['version'],
            'config': get_config(),
            'system_info': {
                'os': platform.system(),
                'python_version': platform.python_version()
            }
        }
        
        backup_filename = f"dashboard_backup_{datetime.now().strftime('%Y%m%d_%H%M%S')}.json"
        backup_path = os.path.join(os.path.dirname(__file__), '..', 'backups', backup_filename)
        
        # Crear directorio de backups si no existe
        os.makedirs(os.path.dirname(backup_path), exist_ok=True)
        
        with open(backup_path, 'w', encoding='utf-8') as f:
            json.dump(backup_data, f, indent=2, ensure_ascii=False)
        
        logger.info(f"Backup creado: {backup_filename}")
        
        return jsonify({
            'success': True,
            'backup_file': backup_filename,
            'backup_path': backup_path,
            'size': os.path.getsize(backup_path)
        })
        
    except Exception as e:
        logger.error(f"Error creando backup: {str(e)}")
        return jsonify({'error': str(e)}), 500

@system_bp.route('/restart', methods=['POST'])
def restart_system():
    """Reiniciar el sistema (solo el dashboard principal)"""
    
    try:
        logger.info("Reiniciando sistema...")
        
        # En un entorno real, esto reiniciaría el servicio
        # Por ahora, solo devolvemos confirmación
        
        return jsonify({
            'success': True,
            'message': 'Sistema programado para reinicio',
            'note': 'El reinicio se realizará en unos segundos'
        })
        
    except Exception as e:
        logger.error(f"Error reiniciando sistema: {str(e)}")
        return jsonify({'error': str(e)}), 500

@system_bp.route('/shutdown', methods=['POST'])
def shutdown_system():
    """Apagar el sistema de forma controlada"""
    
    try:
        logger.info("Apagando sistema...")
        
        # En un entorno real, esto apagaría todos los servicios
        # Por ahora, solo devolvemos confirmación
        
        return jsonify({
            'success': True,
            'message': 'Sistema programado para apagado',
            'note': 'Todos los módulos se detendrán de forma controlada'
        })
        
    except Exception as e:
        logger.error(f"Error apagando sistema: {str(e)}")
        return jsonify({'error': str(e)}), 500

@system_bp.route('/processes')
def system_processes():
    """Listar procesos del sistema relacionados con el dashboard"""
    
    try:
        processes = []
        
        for proc in psutil.process_iter(['pid', 'name', 'cpu_percent', 'memory_percent', 'cmdline']):
            try:
                proc_info = proc.info
                cmdline = ' '.join(proc_info['cmdline']) if proc_info['cmdline'] else ''
                
                # Filtrar procesos relacionados con el dashboard
                if any(keyword in cmdline.lower() for keyword in ['streamlit', 'flask', 'filebrowser', 'dashboard']):
                    processes.append({
                        'pid': proc_info['pid'],
                        'name': proc_info['name'],
                        'cpu_percent': proc_info['cpu_percent'],
                        'memory_percent': proc_info['memory_percent'],
                        'cmdline': cmdline
                    })
            except (psutil.NoSuchProcess, psutil.AccessDenied):
                continue
        
        return jsonify({
            'processes': processes,
            'count': len(processes),
            'timestamp': datetime.now().isoformat()
        })
        
    except Exception as e:
        logger.error(f"Error obteniendo procesos: {str(e)}")
        return jsonify({'error': str(e)}), 500

# Funciones auxiliares
def get_config() -> Dict[str, Any]:
    """Obtener configuración del sistema"""
    
    try:
        if os.path.exists(SYSTEM_CONFIG_FILE):
            with open(SYSTEM_CONFIG_FILE, 'r', encoding='utf-8') as f:
                config = json.load(f)
                # Combinar con configuración por defecto
                return {**DEFAULT_CONFIG, **config}
        else:
            return DEFAULT_CONFIG.copy()
    except Exception as e:
        logger.error(f"Error cargando configuración: {str(e)}")
        return DEFAULT_CONFIG.copy()

def save_config(config: Dict[str, Any]):
    """Guardar configuración del sistema"""
    
    # Crear directorio si no existe
    os.makedirs(os.path.dirname(SYSTEM_CONFIG_FILE), exist_ok=True)
    
    with open(SYSTEM_CONFIG_FILE, 'w', encoding='utf-8') as f:
        json.dump(config, f, indent=2, ensure_ascii=False)

def validate_config(config: Dict[str, Any]) -> Dict[str, Any]:
    """Validar configuración del sistema"""
    
    errors = []
    
    # Validaciones básicas
    if 'system' not in config:
        errors.append("Sección 'system' requerida")
    
    if 'modules' not in config:
        errors.append("Sección 'modules' requerida")
    
    # Validar valores específicos
    if 'system' in config:
        if 'monitoring_interval' in config['system']:
            if not isinstance(config['system']['monitoring_interval'], int) or config['system']['monitoring_interval'] < 10:
                errors.append("monitoring_interval debe ser un entero >= 10")
    
    return {
        'valid': len(errors) == 0,
        'errors': errors
    }

def get_logs(lines: int = 100, level: str = 'all') -> list:
    """Obtener logs del sistema"""
    
    logs = []
    
    try:
        if os.path.exists(LOG_FILE):
            with open(LOG_FILE, 'r', encoding='utf-8') as f:
                all_lines = f.readlines()
                
                # Filtrar por nivel si se especifica
                if level != 'all':
                    filtered_lines = [line for line in all_lines if level.upper() in line]
                else:
                    filtered_lines = all_lines
                
                # Obtener últimas líneas
                recent_lines = filtered_lines[-lines:] if len(filtered_lines) > lines else filtered_lines
                
                for line in recent_lines:
                    logs.append({
                        'timestamp': datetime.now().isoformat(),  # Placeholder
                        'level': 'INFO',  # Placeholder
                        'message': line.strip()
                    })
    except Exception as e:
        logger.error(f"Error leyendo logs: {str(e)}")
        logs.append({
            'timestamp': datetime.now().isoformat(),
            'level': 'ERROR',
            'message': f"Error leyendo logs: {str(e)}"
        })
    
    return logs

def check_modules_health() -> Dict[str, Any]:
    """Verificar salud de los módulos"""
    
    import requests
    
    modules_status = {
        'overall_status': 'healthy',
        'modules': {}
    }
    
    modules_to_check = {
        'file_explorer': 'http://localhost:8060/api/status',
        'data_analysis': 'http://localhost:8050',
        'report_generator': 'http://localhost:8070'
    }
    
    offline_count = 0
    
    for module_name, url in modules_to_check.items():
        try:
            response = requests.get(url, timeout=3)
            modules_status['modules'][module_name] = {
                'status': 'healthy' if response.status_code == 200 else 'warning',
                'response_time': response.elapsed.total_seconds(),
                'status_code': response.status_code
            }
        except Exception as e:
            modules_status['modules'][module_name] = {
                'status': 'critical',
                'error': str(e)
            }
            offline_count += 1
    
    # Determinar estado general de módulos
    total_modules = len(modules_to_check)
    if offline_count == 0:
        modules_status['overall_status'] = 'healthy'
    elif offline_count < total_modules:
        modules_status['overall_status'] = 'warning'
    else:
        modules_status['overall_status'] = 'critical'
    
    return modules_status

def get_system_uptime() -> str:
    """Obtener tiempo de actividad del sistema"""
    
    try:
        boot_time = psutil.boot_time()
        uptime_seconds = datetime.now().timestamp() - boot_time
        uptime_delta = timedelta(seconds=uptime_seconds)
        
        days = uptime_delta.days
        hours, remainder = divmod(uptime_delta.seconds, 3600)
        minutes, _ = divmod(remainder, 60)
        
        return f"{days}d {hours}h {minutes}m"
    except:
        return "unknown"

