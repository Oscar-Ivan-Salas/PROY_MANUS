#!/usr/bin/env python3
"""
Dashboard Tesis Pro - Aplicación Principal Unificada
Panel central que integra todos los módulos del sistema
"""

import os
import sys
import json
import requests
from datetime import datetime
from flask import Flask, send_from_directory, jsonify, request, render_template_string
from flask_cors import CORS

# DON'T CHANGE THIS !!!
sys.path.insert(0, os.path.dirname(os.path.dirname(__file__)))

from src.models.user import db
from src.routes.user import user_bp
from src.routes.dashboard import dashboard_bp
from src.routes.modules import modules_bp
from src.routes.system import system_bp

# Crear aplicación Flask
app = Flask(__name__, 
           static_folder=os.path.join(os.path.dirname(__file__), 'static'),
           template_folder=os.path.join(os.path.dirname(__file__), 'templates'))

# Configuración
app.config['SECRET_KEY'] = 'dashboard_tesis_pro_2024_secure_key'
app.config['SQLALCHEMY_DATABASE_URI'] = f"sqlite:///{os.path.join(os.path.dirname(__file__), 'database', 'app.db')}"
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False

# Habilitar CORS para comunicación entre módulos
CORS(app, origins="*")

# Configuración del dashboard
DASHBOARD_CONFIG = {
    'title': 'Dashboard Tesis Pro',
    'version': '2.0.0',
    'modules': {
        'file_explorer': {
            'name': 'Explorador de Archivos',
            'description': 'Gestión profesional de archivos y datos',
            'port': 8058,
            'api_port': 8060,
            'icon': '📁',
            'status': 'unknown',
            'url': 'http://localhost:8058'
        },
        'data_analysis': {
            'name': 'Análisis Estadístico',
            'description': 'Análisis avanzado y visualizaciones interactivas',
            'port': 8050,
            'icon': '📊',
            'status': 'unknown',
            'url': 'http://localhost:8050'
        },
        'report_generator': {
            'name': 'Generador de Informes',
            'description': 'Reportes profesionales en múltiples formatos',
            'port': 8070,
            'icon': '📄',
            'status': 'unknown',
            'url': 'http://localhost:8070'
        }
    },
    'theme': {
        'primary_color': '#2196F3',
        'secondary_color': '#1976D2',
        'accent_color': '#FF9800',
        'success_color': '#4CAF50',
        'warning_color': '#FF9800',
        'error_color': '#F44336'
    }
}

# Registrar blueprints
app.register_blueprint(user_bp, url_prefix='/api/users')
app.register_blueprint(dashboard_bp, url_prefix='/api/dashboard')
app.register_blueprint(modules_bp, url_prefix='/api/modules')
app.register_blueprint(system_bp, url_prefix='/api/system')

# Inicializar base de datos
db.init_app(app)
with app.app_context():
    db.create_all()

# Rutas principales
@app.route('/')
def index():
    """Página principal del dashboard"""
    return send_from_directory(app.static_folder, 'index.html')

@app.route('/api/config')
def get_config():
    """Obtener configuración del dashboard"""
    # Verificar estado de módulos
    config = DASHBOARD_CONFIG.copy()
    
    for module_key, module_info in config['modules'].items():
        try:
            if module_key == 'file_explorer':
                # Verificar API del explorador de archivos
                response = requests.get(f"http://localhost:{module_info['api_port']}/api/status", timeout=2)
                config['modules'][module_key]['status'] = 'online' if response.status_code == 200 else 'offline'
            else:
                # Verificar otros módulos
                response = requests.get(f"http://localhost:{module_info['port']}", timeout=2)
                config['modules'][module_key]['status'] = 'online' if response.status_code == 200 else 'offline'
        except:
            config['modules'][module_key]['status'] = 'offline'
    
    return jsonify(config)

@app.route('/api/status')
def system_status():
    """Estado general del sistema"""
    status = {
        'timestamp': datetime.now().isoformat(),
        'dashboard_version': DASHBOARD_CONFIG['version'],
        'modules_status': {},
        'system_health': 'healthy'
    }
    
    offline_count = 0
    
    for module_key, module_info in DASHBOARD_CONFIG['modules'].items():
        try:
            if module_key == 'file_explorer':
                response = requests.get(f"http://localhost:{module_info['api_port']}/api/status", timeout=2)
                module_status = 'online' if response.status_code == 200 else 'offline'
            else:
                response = requests.get(f"http://localhost:{module_info['port']}", timeout=2)
                module_status = 'online' if response.status_code == 200 else 'offline'
        except:
            module_status = 'offline'
        
        status['modules_status'][module_key] = module_status
        if module_status == 'offline':
            offline_count += 1
    
    # Determinar salud del sistema
    total_modules = len(DASHBOARD_CONFIG['modules'])
    if offline_count == 0:
        status['system_health'] = 'healthy'
    elif offline_count < total_modules:
        status['system_health'] = 'degraded'
    else:
        status['system_health'] = 'critical'
    
    return jsonify(status)

@app.route('/api/modules/<module_name>/proxy/<path:endpoint>')
def module_proxy(module_name, endpoint):
    """Proxy para comunicación con módulos"""
    if module_name not in DASHBOARD_CONFIG['modules']:
        return jsonify({'error': 'Módulo no encontrado'}), 404
    
    module_info = DASHBOARD_CONFIG['modules'][module_name]
    
    # Determinar puerto correcto
    if module_name == 'file_explorer' and endpoint.startswith('api/'):
        target_port = module_info['api_port']
    else:
        target_port = module_info['port']
    
    target_url = f"http://localhost:{target_port}/{endpoint}"
    
    try:
        # Reenviar la petición
        if request.method == 'GET':
            response = requests.get(target_url, params=request.args, timeout=10)
        elif request.method == 'POST':
            response = requests.post(target_url, json=request.json, timeout=10)
        else:
            return jsonify({'error': 'Método no soportado'}), 405
        
        return jsonify(response.json()), response.status_code
    
    except requests.exceptions.RequestException as e:
        return jsonify({'error': f'Error de comunicación con {module_name}: {str(e)}'}), 503

@app.route('/health')
def health_check():
    """Health check para monitoreo"""
    return jsonify({
        'status': 'healthy',
        'timestamp': datetime.now().isoformat(),
        'version': DASHBOARD_CONFIG['version']
    })

@app.route('/<path:path>')
def serve_static(path):
    """Servir archivos estáticos"""
    static_folder_path = app.static_folder
    if static_folder_path is None:
        return "Static folder not configured", 404

    if path != "" and os.path.exists(os.path.join(static_folder_path, path)):
        return send_from_directory(static_folder_path, path)
    else:
        # Redirigir a index.html para SPA routing
        index_path = os.path.join(static_folder_path, 'index.html')
        if os.path.exists(index_path):
            return send_from_directory(static_folder_path, 'index.html')
        else:
            return "index.html not found", 404

# Manejo de errores
@app.errorhandler(404)
def not_found(error):
    return jsonify({'error': 'Endpoint no encontrado'}), 404

@app.errorhandler(500)
def internal_error(error):
    return jsonify({'error': 'Error interno del servidor'}), 500

if __name__ == '__main__':
    print("🚀 Iniciando Dashboard Tesis Pro...")
    print(f"📊 Versión: {DASHBOARD_CONFIG['version']}")
    print("🌐 Acceso: http://localhost:3000")
    print("🔧 API: http://localhost:3000/api")
    print("💡 Presiona Ctrl+C para detener")
    
    app.run(host='0.0.0.0', port=3000, debug=True)

